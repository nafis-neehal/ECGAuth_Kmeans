#general-imports
import numpy as np
import pandas as pd
import time
import datetime as dt

#dowhy-imports
import dowhy
from dowhy import CausalModel

import logging
logging.getLogger("dowhy").setLevel(logging.WARNING)
import warnings
from sklearn.exceptions import DataConversionWarning
warnings.filterwarnings(action='ignore', category=DataConversionWarning)

#scikit learn- imports
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import AgglomerativeClustering as AgClust
from sklearn.preprocessing import minmax_scale

#custom-imports
from data_functions import make_date_to_MYR
from tqdm import tqdm



def _new_diab(group, whole_dat, months, month_to_index, name, onset = 'CC_DIABETES'):
    """
    function to count diabetes onset- or any other onset
    
    group = month group
    wholde_data = all data including group
    months = a list of months in the data
    month_to_index = a mapping between months and their index
    onset (str) = The name of another onset we could study
    
    """
    
    ids = group.PERS_ID.unique()
    myr = group.MYR.values[0]
 
    ii = month_to_index[myr]
    if ii == 0:
        return
    
    month_old = months[ii-1]
    dat = whole_dat[whole_dat.MYR == month_old]
    commonids = np.intersect1d(dat.PERS_ID.unique(), ids)
    comp2 = group[group.PERS_ID.isin(commonids)].sort_values(by = ['PERS_ID']).reset_index(drop =True)

    comp1 = dat[dat.PERS_ID.isin(commonids)].sort_values(by = ['PERS_ID']).reset_index(drop = True)
 
    filter1 = (comp2[onset] == 1)& (comp1[onset] == 0)
   # per_1000 = (10**3/len(group))*(filter1.sum())
    per_1000 = (10**3/len(comp1))*(filter1.sum())
    
    return pd.Series([len(comp1), filter1.sum(), per_1000], index =['Sample', name, 'Per_1000'])

def diabet_onset( data, name, onset = 'CC_DIABETES' ):
    
    """
    calculates new diabetes patients per month
    Or other onset
    
    """
    
    months = data.MYR.unique()
    months.sort()
    months_to_index = dict(zip(months, [i for i in np.arange(len(months))]))
    
    data.drop_duplicates(subset = ('PERS_ID', 'MYR'), inplace = True)
    
    onset = data.groupby('MYR').apply(lambda x: _new_diab(x, data, months, months_to_index, name, onset = onset))
    
    return onset

def switchesf(group, onset = 'CC_DIABETES'):
    """
    counts the switches from 0-1 and 1-0 (to catch bugs in diabetes data)
    
    """
    
    group1 = group.sort_values(by = 'MYR')[onset].values
   # print(group1)
    switch01 = 0
    switch10 = 0
    
    for i, val in enumerate(group1):
        #print(val)
        if i == 0:
            continue
       # print('HERE')
        if (val == 1) and (group1[i-1] == 0):
        #    print('HERE0')
            switch01 +=1
        
        if (val == 0) and (group1[i-1] == 1):
           # print('HERE2')
            switch10 += 1
            
        
    return pd.Series([switch01, switch10], index = ['Swithc01', 'Switch10'])
        
def _in_canary(group, canary):
    """
    gives a flag = 1 to the dates
    from the beginning of a patients inclusion
    in canary to the future
    
    """
    
    idi = group.PERS_ID.values[0]
    
    #a person is considered in canary from its registered date and onwards
    register = canary[canary.PERS_ID == idi].MYR.values[0]
    group.loc[group.MYR >= register, 'IN_CANARY'] = 1
    return group

def in_canary(treated, canary):
    """
    wrapper function that uses
    _in_canary 
    to return only patients
    from the momement they were registered in canary
    onwards
    
    """
    
    ## add flag initially 0 for patients in canary
    treated['IN_CANARY'] = 0
    treated2 = treated.groupby('PERS_ID').apply(lambda x: _in_canary(x, canary[['PERS_ID', 'MYR']]))
    filt = treated2.IN_CANARY == 1
    
    return treated2[filt].reset_index(drop = True)
    

def process_canary(canary, max_month):
    """
    keep only IDs
    transform register date to MYR
    format
    drop data after maximum month in pmpm
    
    """
    
    canary = canary[['PERS_ID', 'REGISTER_DATE']].copy()
    canary['MYR'] = canary.REGISTER_DATE.apply(make_date_to_MYR)
    canary.drop(columns = ['REGISTER_DATE'], inplace = True)
    canary = canary[canary.MYR <= max_month].reset_index(drop = True)
    
    return canary

def get_tc(pmpm, canary):
    
    """
    separate pmpm in 
    treated and control patients
    
    """
    pmpm.MBR_GNDR.replace(to_replace = {'F':0, 'M': 1}, inplace = True)
    canary_ids = canary.PERS_ID.unique()
    treated = pmpm[pmpm.PERS_ID.isin(canary_ids)]
    treated = treated.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    controls = pmpm[~pmpm.PERS_ID.isin(canary_ids)].reset_index(drop = True)
    
    
    return treated, controls



#--------------------------
#-------- Matching starts here

def match_data(treated, controls, month = -1, 
               ccn = None, nn = 2 ):
    
    """
    match data treated and controls 
    in a specific year-month
    
    treated = treatment group data
    controls = control group data
    month = YEAR MONTH TO match
    ccn = common_causes names for matching
    nn = how many neighbors to get
    
    """
    if month == -1:
        print('Wrong month abort')
        return
    
    #get the Year Month for matching
    treated_new = treated[treated.MYR == month].reset_index(drop = True)
    controls_new = controls[controls.MYR == month].reset_index(drop = True)
    
    #Specify a boolean variable TREATED
    treated_new['TREATED'] = True
    controls_new['TREATED'] = False
    
    #make gender from string to int
    controls_new.MBR_GNDR.replace(to_replace = {'F':0, 'M':1}, inplace = True)
    treated_new.MBR_GNDR.replace(to_replace = {'F':0, 'M':1}, inplace = True)
    
    data = pd.concat((controls_new, treated_new), axis = 0, ignore_index = True)
    
    #we do not care about the outcome we just want the matched
    #the dowhy package needs an outcome so we specify it as 1
    data['OUTCOME'] = 1
    
    #match with do why
    propensity_scores = do_matching(data, ccn)
    
    #after this step data matrix is automatically populated
    #with propensity scores
    matched_set, indices = get_matches(data, nn)
    
    return matched_set, matched_set.PERS_ID.unique(), data, indices


def get_matches(data, nn):
    """
    get matches based on propensity 
    score nearest neighbors
    
    used  as a helper function to "match_data"
    function
    
    data = processed data with controls treated
    outcome variable and treated variable
    """
    
    #Separate Control Treatment Data
    Xtr = data[data.TREATED == 1].reset_index(drop = True)
    Xcon = data[data.TREATED == 0].reset_index(drop = True)
    
    #get the nearest neighbors of the treated 
    #subjects to the control subjects
    neighbors = NearestNeighbors(n_neighbors=nn).fit(X = Xcon.propensity_score.values.reshape(-1,1))
    matched_indices = neighbors.kneighbors(X = Xtr.propensity_score.values.reshape(-1,1),
                                           n_neighbors=nn,
                                           return_distance = False)
    
    indices = matched_indices.reshape(-1,1)
    matched = Xcon.iloc[indices[:,0]].reset_index(drop = True)
    matched.drop_duplicates(subset = ('PERS_ID', 'MYR'), inplace = True)
    
    return matched, indices

def get_matches_month(data, nn, month, prop_treated):
    """
    get matches based on propensity 
    score nearest neighbors
    
    data: control data with propensity scores
    nn:number of neighbors to match
    month: take controls only from that year-month
    prop_treated: propensity score of the treated patient
    on that year-month
    
    """
    
    #Get controls on the specific Year Month --> month
    Xcon = data[data.MYR.isin([month])].reset_index(drop = True)
    Xtr = np.array(prop_treated)
    
    #get the nn nearest neighbors of the treated in the controls
    neighbors = NearestNeighbors(n_neighbors=nn).fit(X = Xcon.propensity_score.values.reshape(-1,1))
    matched_indices = neighbors.kneighbors(X = Xtr.reshape(-1,1),
                                           n_neighbors=nn,
                                           return_distance = False)
    
    indices = matched_indices.reshape(-1,1)
    matched = Xcon.iloc[indices[:,0]].reset_index(drop = True)
    matched.drop_duplicates(subset = ('PERS_ID', 'MYR'), inplace = True)
    
    return matched, indices
    
    
def do_matching(data, common_causes_names,
                method = "backdoor.propensity_score_stratification"):
    
    """
    given common_causes_names and data
    calculate propensity scores with do why
    method = matching methods from dowhy
    see "causal_analysis" function below
    """
    
    data1 = {'df':data, 
        'common_causes_names':list(common_causes_names), 
        'outcome':'OUTCOME', 
        'treatment_name':'TREATED'}
    
    
    return causal_analysis(data1, 'outcome', method = method)
    

    
    
def causal_analysis(data, outcome_name,  method = "backdoor.propensity_score_stratification"):
    
    """
    methods = "backdoor.propensity_score_stratification",
                "backdoor.propensity_score_matching"
    
    """
    #define causal model
    model = CausalModel(
            data=data['df'],
            treatment=data['treatment_name'],
            outcome=data[outcome_name],
            common_causes=data['common_causes_names'],
            )
    
    #check if it is possible the estimand to be estimated
    identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)
    method_params = {'random_state': 50}
    #calculate propensities
    propensity_match_estimate = model.estimate_effect(identified_estimand,
                            method_name = method,
                            test_significance = False,
                            confidence_intervals = False,
                            target_units="att")
    
    return propensity_match_estimate




#match every month
def match_data_per_month(treated, controls, 
                        common_causes_names = None,
                        neighbors = 30):
    
    #get months for controls and treated
    months_treated = treated.MYR.unique()
    months_controls = controls.MYR.unique()
    
    #get common months
    months = np.sort(np.intersect1d(months_treated, months_controls))
    assert 2*len(months)==(len(months_treated)+len(months_controls)),"Tre and Contr Uneq Months"
    month_ids = {}
    
    #match by month
    for i, month_to_match in enumerate(months):
        print("MYR:{}...matching".format(month_to_match))
        _, matched_ids, _, _ = match_data(treated.copy(), controls.copy(),
                     month = month_to_match,
                     ccn = common_causes_names,
                     nn = neighbors)
        month_ids[month_to_match] = matched_ids
        
    print('Creating the Final Controls Dataset')
    new_controls = create_controls_from_month_ids(months, month_ids, controls.copy())
    
    return new_controls
        
def create_controls_from_month_ids(months, month_ids, controls):
    
    month_to_index = dict(zip(months, [i for i in range(len(months))]))
    
    for i, (month, ids) in enumerate(month_ids.items()):
        
        if i==0:
            filteri = controls.PERS_ID.isin(ids) & controls.MYR.isin([month])
            data = controls[filteri].copy()
        
        else:
            prev_month = months[i-1]
            filteri = (controls.PERS_ID.isin(ids) &
                        controls.MYR.isin([prev_month,month]))
            
            data = pd.concat((data, controls[filteri]), axis = 0, ignore_index = True)
    
    data = data.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index()
    return data
    
    
def filter_first_month_diabetes( data, onset = 'CC_DIABETES' ):
    """
    filters the ids with first month Diabetes(or othe onset)
    
    """
    ids = not_first_month_diabetes(data.copy(), onset = onset)
    final_ids = ids[ids.First_Month == True].PERS_ID
    data_filt = data[data.PERS_ID.isin(final_ids)].reset_index(drop = True)
    
    return data_filt

def not_first_month_diabetes( data, onset = 'CC_DIABETES' ):
    """
    Returns all the ids where the
    first month did not have a particular
    disease (example DIABETES)
    
    """
    data = data.sort_values(by = ['PERS_ID', 'MYR']).reset_index(drop = True)
    ids = data.groupby('PERS_ID').apply( lambda x: pd.Series([x[onset].iloc[0] == 0], 
                                                             index = ['First_Month'])).reset_index()
    return ids



##### MATCHING FRAMEWORK
def matched_population(treated, controls, func, args):
    """
    wrapper function that returns a matched
    population
    
    treated = the treatment group
    controls = the control group
    func = the function to perform matching
    args = the arguments that will go in the matching function
    (args should be a dict)
    
    """
    
    name = func.__name__
    print('Mathcing Function:', name)
    return func(treated, controls, **args)

### NNB matching
#func
def nearest_neighbor_func(treated = None, controls = None, 
                          match_on = None, 
                         neighbors_per_treated = 10, onset = 'CC_DIABETES'):
    
    """
    treated: pandas array
           the treated population
    controls: pandas array
           the controls population
    match_on: covariates to do the matching on
    neighbors_per_treated: int: default 10
            how many matched controls
            to get per treated patient
    onset = onset we study (CC_DIABETES) should
            be zero at the first day of controls
            enetring the study
    
    """
    
    #copy treated controls
    nn = neighbors_per_treated
    tr = treated.copy()
    cr = controls.copy()
    cr = cr[cr[onset] == 0].reset_index(drop = True)
    cr.ALLOW_AMT = np.log(cr.ALLOW_AMT.values + 10**(-7))
    tr = tr.sort_values(by = ['PERS_ID', 'MYR']).reset_index(drop = True)
    tr2 = tr.groupby('PERS_ID').apply(lambda x: pd.Series(x.iloc[0])).reset_index(drop = True)
   # return tr2, tr2
    data_per_id_month = {}
    for i, (index, row) in enumerate(tr2.iterrows()):
        
        month = row.MYR
        age = row.AGE_AT_MIDMONTH
        idi = row.PERS_ID
        gender = row.MBR_GNDR
        #filter the controls by month and age
        filteri = ((cr.MYR.isin([month])) & 
                   (cr.AGE_AT_MIDMONTH <= age+4) & (cr.AGE_AT_MIDMONTH >= age-4)&(cr.MBR_GNDR == gender))
        
        cr_i = cr[filteri].reset_index(drop = True)
        
        #get nearest neighbors based on the rest features to match on
        cr_ii = cr_i[match_on]
        rowi = row[match_on]
        rowi.ALLOW_AMT = np.log(rowi.ALLOW_AMT + 10**(-7))
        
        #get the neighbors for treated patient i
        neighbors = NearestNeighbors(n_neighbors=nn).fit(X = cr_ii.values)
        matched_indices = neighbors.kneighbors(X = rowi.values.reshape(1,-1),
                                           n_neighbors=nn,
                                           return_distance = False)
        
        indices = matched_indices.reshape(-1,1)
        matched_data_i = cr_i.iloc[indices[:,0]].reset_index(drop = True)
        matched_data_i.drop_duplicates(subset = ('PERS_ID', 'MYR'), inplace = True)
        matched_data_i.reset_index(drop = True)
        data_per_id_month[(idi, month)] = matched_data_i
        
        #get the controls corresponding to the macthed data
        filteri = (controls.MYR >= month) & (controls.PERS_ID.isin(matched_data_i.PERS_ID.unique()))
        xcon_month_ids  = controls.copy()[filteri].reset_index(drop = True)
        if i == 0:
            all_controls = xcon_month_ids
        else:
            all_controls = pd.concat((all_controls, xcon_month_ids), axis = 0, ignore_index = True )
            
    all_controls = all_controls.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)      
    return data_per_id_month, all_controls
            
        

### Propensity Matching        
def propensity_func(treated = None, controls = None, 
                    match_on = None, neighbors_per_treated = 10, onset = 'CC_DIABETES'):
    
    """
    treated: pandas array
           the treated population
    controls: pandas array
           the controls population
    match_on: covariates to do the matching on
    neighbors_per_treated: int: default 10
            how many matched controls
            to get per treated patient
    
    """
    
    #prepare dataset for matching
    common_causes_names = match_on
    outcome_name = 'outcome'
    npt = neighbors_per_treated
    
    tr = treated.copy()
    con = controls.copy()
    tr['TREATED'] = True
    con['TREATED'] = False
    data = pd.concat((tr, con), axis = 0, ignore_index = True )
    data['OUTCOME'] = 1
    data = data[data[onset] == 0].reset_index(drop = True)
    
    #learn propensity score function
    data1 = {'df':data, 
        'common_causes_names':list(common_causes_names), 
        outcome_name:'OUTCOME', 
        'treatment_name':'TREATED'}
    
    print('Propensity Score Matching...fitting model')
    result = causal_analysis(data1, outcome_name)
    
    print('Creating Matched Set...')
    matched_set = get_neighbors(data, controls, treated.columns, kneigh = npt)
    
    return matched_set
    
    
def get_neighbors(data, controls, common_cols,  kneigh = 10):
    
    xtr = data[data.TREATED == True].reset_index(drop = True)
    xcon = data[data.TREATED== False].reset_index(drop = True)
    
    xtr2 = xtr.sort_values(by = ['PERS_ID', 'MYR']).reset_index(drop = True)
    
    #patients in their register date
    xtr3 = xtr2.groupby('PERS_ID').apply(lambda x: pd.Series(x.iloc[0])).reset_index(drop = True)
    data_per_id_month = {}
    for i, (index, row) in tqdm(enumerate(xtr3.iterrows())):
        month = row.MYR
        idi = row.PERS_ID
        propensity = row.propensity_score
        
        matched_data_i, _ = get_matches_month(xcon, kneigh, month, propensity)
        data_per_id_month[(idi, month)] = matched_data_i
        
        #get the control data from this month and onwards foir treated patient i
        filteri = (controls.MYR >= month) & (controls.PERS_ID.isin(matched_data_i.PERS_ID.unique()))
        xcon_month_ids  = controls.copy()[filteri].reset_index(drop = True)
        if i == 0:
            all_controls = xcon_month_ids
        else:
            all_controls = pd.concat((all_controls, xcon_month_ids), axis = 0, ignore_index = True )
            
     
    all_controls = all_controls.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    return data_per_id_month, all_controls[common_cols]

#### Random Matching
def random_matching_func(treated, controls, neighbors_per_treated = 20, onset = 'CC_DIABETES'):
    
    #neighbors per treated
    nbr = neighbors_per_treated
    controls1 = controls.copy()
    
    #get treated in their register date
    tr_reg = treated.sort_values(by =['PERS_ID', 'MYR']).reset_index(drop = True).groupby('PERS_ID').apply(lambda x: pd.Series(x.iloc[0])).reset_index(drop = True)
    
    #get the count of the YEAR MONTHS
    myr_counts = tr_reg.MYR.value_counts().reset_index().rename(columns = {'index':'MYR', 'MYR':'COUNT'})
    
    #Get the unique register dates (for each MYR we will sample people neighbors from the controls)
    register_dates = myr_counts.MYR.unique()
    
    #make sure all the controls have 0 onset when they are selected
    pmpm_diab0 = controls1[controls1[onset] == 0].reset_index(drop = True)
    pmpm_diab0 = pmpm_diab0[pmpm_diab0.MYR.isin(register_dates)].reset_index(drop = True)
    
    #for each register date sample controls
    random_controls = pmpm_diab0.groupby('MYR').apply(lambda x: random_sampling(x, myr_counts, controls, nbr)).reset_index(drop = True)
    random_controls = random_controls.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    
    return random_controls

def random_sampling(group, myr_counts, full_pmpm, neighbors):
    
    """
    
    sample values based on the myr_counts
    
    """
    
    myr = group.MYR.iloc[0]
    myr_sample = myr_counts[myr_counts.MYR == myr].COUNT.iloc[0]
    to_sample = int(neighbors * myr_sample)
    
    sample_ids = group.sample(n = to_sample).PERS_ID.unique()
    filteri = (full_pmpm.MYR >= myr) & (full_pmpm.PERS_ID.isin(sample_ids))
    full_pmpm2 = full_pmpm[filteri].reset_index(drop = True)
    
    return full_pmpm2
    

### survival analysis
def survival_diabetes(group, onset = 'CC_DIABETES'):
    
    #group1 = group.sort_values(by = 'MYR').reset_index(drop = True)
    onsett = group[onset].values
    indx = np.where(onsett == 1)[0]
    idi = group.PERS_ID.iloc[0]
    if indx.size > 0:
        duration = indx[0] + 1
        obs = 1
    else:
        duration = len(group)
        obs = 0
    cols = np.setdiff1d(group.columns, ['PERS_ID', 'MYR', onset])
    group1 = group.reset_index(drop = True)
    return pd.Series([idi,duration, obs ]+list(group1.loc[0, cols].values),
                     index = ['PERS_ID', 'T', 'E']+list(cols))
        

### CLUSETRING ALGORITHM     
### Computer Linakge matrix for Agglomerative Clustering
def get_linkage(model):
    # Create linkage matrix 

    # create the counts of samples under each node
    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)
    for i, merge in enumerate(model.children_):
        current_count = 0
        for child_idx in merge:
            if child_idx < n_samples:
                current_count += 1  # leaf node
            else:
                current_count += counts[child_idx - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack([model.children_, model.distances_,
                                      counts]).astype(float)
    
    return linkage_matrix


def agglomerative(treated, columns_to_match, to_log = ['ALLOW_AMT']):
    
    """
    Fits an agglomerative clustering with ward metric
    computes linkage function
    returns the fitted model and the two canary clusters
    
    """
    #get patients from their registered date and onwards
    can_reg = treated.sort_values(by = ['PERS_ID','MYR']).groupby('PERS_ID').apply(lambda x : 
                                              pd.Series(x.iloc[0])).reset_index(drop = True)
    
    #compute the log cost
    if to_log:
        can_reg[to_log] = np.log(can_reg[to_log]+10**(-10))
    
    #min max scaler for clustering
    data_cluster = minmax_scale(can_reg[columns_to_match].values)
    
    #fit hierarchical model
    model = AgClust(n_clusters = 2, linkage = 'ward', compute_distances = True).fit(data_cluster)
    
    #get linkage function
    link = get_linkage(model)
    
    #separate treated into clusters
    labels = model.labels_
    id0 = can_reg[labels == 0].PERS_ID.unique()
    id1 = can_reg[labels == 1].PERS_ID.unique()
    treated0 = treated[treated.PERS_ID.isin(id0)].reset_index(drop = True)
    treated1 = treated[treated.PERS_ID.isin(id1)].reset_index(drop = True)

    return treated0, treated1, model, link, can_reg[columns_to_match]