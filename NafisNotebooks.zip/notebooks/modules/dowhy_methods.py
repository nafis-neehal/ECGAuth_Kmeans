from dowhy import CausalModel

methods = {'LR':  'backdoor.linear_regression', 
           'PSM': 'backdoor.propensity_score_matching',
           'PSS': 'backdoor.propensity_score_stratification', 
           'PSW': 'backdoor.propensity_score_weighting'}


def run_do_why(data, treatment_label, outcome_label, common_causes_list, method_name, target_units):
    
    #----------------------------
    #step 1: Create Causal Model
    #----------------------------
    model=CausalModel(
            data = data,
            treatment=treatment_label,
            outcome=outcome_label,
            common_causes=common_causes_list
            )
    print("Step 1: Causal Model Created")
    
    #------------------------------
    #step 2: Identify the Estimand
    #------------------------------
    identified_estimand = model.identify_effect(proceed_when_unidentifiable=True)
    print("Step 2: Estimand Identified")

    #------------------------------
    #step 3: Estimating the Effect
    #------------------------------
    estimate = model.estimate_effect(identified_estimand,
            method_name=method_name,
            target_units = target_units
    )
    print("Step 3: Estimated the treatment effect")
    print("Causal Estimate is " + str(estimate.value))

    #------------------------------
    #step 4: Refutation
    #------------------------------
    print("Step 4: Refutation")
    #refute using common cause
    #solution: Does the estimation method change its estimate after we add an independent random variable as a common cause to the dataset? (Hint: It should not)
    refute_random_common_cause = model.refute_estimate(
                                            identified_estimand,
                                            estimate,
                                            method_name="random_common_cause"
                                        )
    print("a. After random common cause refutation --")
    print(refute_random_common_cause)

    #refute using placebo treatment
    #What happens to the estimated causal effect when we replace the true treatment variable with an independent random variable? (Hint: the effect should go to zero)
    refute_placebo_treatment = model.refute_estimate(
                                        identified_estimand,
                                        estimate,
                                        method_name="placebo_treatment_refuter",
                                        placebo_type="permute"
                                    )
    print("b. After placebo treatment refutation --")
    print(refute_placebo_treatment)

    #refute using random subset
    #Does the estimated effect change significantly when we replace the given dataset with a randomly selected subset? (Hint: It should not)
    refute_random_subset = model.refute_estimate(
                                        identified_estimand,
                                        estimate,
                                        method_name="data_subset_refuter",
                                        subset_fraction=0.8
                                )
    print("c. After random subset refutation --")
    print(refute_random_subset)
    
    return model, identified_estimand, estimate