import warnings
def warn(message, category=None, stacklevel=1, source=None):
    pass

warnings.warn = warn
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib as mpl
from sklearn.preprocessing import StandardScaler, MinMaxScaler


from lifelines import CoxPHFitter 
from lifelines import WeibullFitter
from lifelines.statistics import logrank_test
from lifelines.plotting import add_at_risk_counts, rmst_plot
from lifelines.utils import restricted_mean_survival_time
from lifelines import KaplanMeierFitter


from lifelines.plotting import add_at_risk_counts


mpl.style.use('seaborn-paper')

def plot_onset2(*args, names = None):
    
    fig, ax = plt.subplots(2,2, figsize = (15, 9))
    for i, arg in enumerate(args):
        xx = np.arange(len(arg))
        ax[0,0].plot(xx, arg.Per_1000, label = names[i])
        ax[0,1].plot(xx, arg.Per_1000.cumsum(), label = names[i])
        ax[1,0].plot(xx, arg.Per_1000.cumsum()-arg.Per_1000.cumsum().iloc[33], label = names[i])

    ax[0,0].grid()
    #ax.set_xticks(jointTr.MYR.values)
    #ax.set_xticklabels([str(date) for date in jointTr.MYR.values], rotation = 45)
    ax[0,0].set_xlabel('Months')
    ax[0,0].set_ylabel('Diabetes Onset Per 1000')
    ax[0,0].legend()
    
    ax[0,1].grid()
    ax[0,1].set_xlabel('Months')
    ax[0,1].set_ylabel('Cumulative Diabetes Onset Per 1000')
    ax[0,1].legend()
    
    ax[1,0].set_xlim(left = 33)
    ax[1,0].set_ylim(bottom = 0)
    ax[1,0].set_xlabel('Months')
    ax[1,0].set_ylabel('Cumulative Diabetes Onset Per 1000 after Month 33')
    ax[1,0].legend()
    
    plt.legend()
    return fig, ax

### For paper
def plot_hist(data1, data2, name_mapping, log_norm_names,*, data3 = None,  save_path = 'res/figs/', dist_plot_args = None):
    """
    data1: pandas dataframe 1
    data2: pandas dataframe 2
    name_mapping: pandas columns --> paper columns
    log_norm_names --> names to log normalize
    data3: optional third dataset
    save_path: where to save the barplots
    dist_plot_args: extra arguments for the distribution plots
    
    
    """
    axes = []
    sns.set_context(context = 'paper')
    sns.set_style('white')
    for name, new_name in name_mapping.items():
        fig, ax  = plt.subplots()
        if name in log_norm_names:
            data1[name] = np.log(data1[name]+1)
            data2[name] = np.log(data2[name]+1)
            
            if data3 is not None:
                data3[name] = np.log(data3[name]+1)
                
        ax = sns.distplot(data2[name], axlabel = new_name,  ax = ax, label = 'Controls', **dist_plot_args, hist_kws = {'color':'r'}, kde_kws = {'color':'r'})
        ax = sns.distplot(data1[name], axlabel = new_name, ax = ax, label = 'Treated',  **dist_plot_args, hist_kws = {'color':'k'},  kde_kws = {'color':'k'})
        
        if data3 is not None:
           
            ax = sns.distplot(data3[name],axlabel = new_name,  ax = ax, label = 'General Population',  **dist_plot_args)


        ax.xaxis.label.set_size(12)
        ax.legend(fontsize = 12)
        ax.set_ylabel('Density', fontsize = 12 )
        axes.append(ax)
        svname = name.replace(" ", '-')+'.pdf'
        plt.show()
        fig.savefig(save_path+svname)
    
    return axes


def save_arrays(data, paths, mapping):
    all_paper = data.droplevel(1, axis = 1)
    all_paper.columns = ['Treated', 'Matched Controls', 'T-Statistic', 'p-value', 'General Population', 'Random Match']
    all_paper.index = mapping.values()
    all_paper = all_paper.round(3)
    all_paper.to_csv(paths[0])
    
    only_means = all_paper[['Treated', 'Matched Controls', 'General Population', 'Random Match']]
    only_means.to_csv(paths[1])
    
    all_paper['Difference'] = all_paper['Treated'] - all_paper['Matched Controls']
    only_stats = all_paper[['Difference', 'T-Statistic', 'p-value']]
    only_stats.to_csv(paths[2])
    only_stats
    
    return (all_paper, only_means, only_stats)



#### RESULTS ON SURVIVAL

def survival_fit_res(names,  *args, model = None,  model_type = 'Cox',
                     model_args = {}, fit_args = {},
                     duration = 'T', events = 'E',
                    filter_cols = [], normalize = None, log_normalize = None,
                    time = 24, outcome = None):
    """
    *args = all data to plot and get results
    names: names of fitted data
    model: which model to fit: (usually KaplanMeier or CoxPHFitter)
    model_args: dict: model parameters
    fit_args : parameters for fit

    returns: dict(names) --> fitted models
    
    """
    if not model:
        print('ERROR: GIVE MODEL')
        return
    fitted = {}
    
    for dat, name in zip(args, names):
        if filter_cols:
            dat = dat[filter_cols].copy()
            #NORMALIZATION
        if log_normalize is not None:
             dat[log_normalize] = np.log(dat[log_normalize]+1)
        if normalize is not None:
             dat[normalize] = MinMaxScaler().fit_transform(dat[normalize].values)
                
        md = model(**model_args)
        if model_type == 'Cox':
            md = md.fit(dat, duration_col = duration, event_col = events, **fit_args)
        else:
            md = md.fit(dat[duration], event_observed = dat[events], **fit_args)
        
        fitted[name] = md
    models = list(fitted.values())
    rmst1 = restricted_mean_survival_time(models[0], t = time)
    rmst2 = restricted_mean_survival_time(models[1], t = time)
    diff = rmst1-rmst2
        
    
    return fitted,diff
        
def make_results(fitted_models, data1, data2,path_tabs = None,
                 path_figs = None,  outcome = None, 
                 model_args = {}, fit_args = {}, surv_model = None,
                 duration = 'T', events = 'E', filter_cols = [], 
                 summary_names = None, log_normalize = None, 
                 normalize = None, kaplan_plot_params = {}, timeline = 24): 
    """
    fitted_models: dictionary name--> survival models
    data1: first data
    data2: second data
    path_tabs==> path to save tabular data
    path_figs==> path to save regular figures
    outcome ==> name of the outcome studied
    
    """
    sns.set_context(context = 'paper')
    sns.set_style('white')
    #logrank test
    logrank_summ = logrank_test(data1['T'], data2['T'], event_observed_A=data1['E'], event_observed_B=data2['E'] ).summary
    logrank_summ.index = [outcome]
    logrank_summ.to_csv(path_tabs+outcome+'_lgrank.csv')
    
    #make graphs
    fig, ax = plt.subplots()
    for name, model in fitted_models.items():
        
        if isinstance(model, KaplanMeierFitter):
            ax = model.plot(**kaplan_plot_params, ax = ax)
        else:
            ax = model.baseline_survival_.plot(ax = ax)
    
    try:
        flag = kaplan_plot_params['at_risk_counts']
        if not flag:
            ax = add_at_risk_counts(*list(fitted_models.values()), ax = ax)
    except:
        pass
    
    ax.collections[0].set_color('r')
    ax.collections[1].set_color('k')
    ax.set_xlabel('Time', fontsize =12)
    ax.set_ylabel('Survival', fontsize = 12)
    ax.lines[0].set_color('r')
    ax.lines[1].set_color('k')
    ax.legend(list(fitted_models.keys()), fontsize = 12)

    fig.savefig(path_figs+outcome+'_survSep.pdf')
    
    ##make partial graph
    dat = pd.concat((data1, data2), axis = 0, ignore_index = True)
    if log_normalize is not None:
             dat[log_normalize] = np.log(dat[log_normalize]+1)
    if normalize is not None:
             dat[normalize] = MinMaxScaler().fit_transform(dat[normalize].values)
    
    if filter_cols:
        dat = dat[filter_cols].copy()
    
    #fit
    md = surv_model(**model_args)
    md = md.fit(dat, duration_col = duration, event_col = events, **fit_args)
    
    ##plot
    fig2, ax2 = plt.subplots()
    ax2 = md.plot_partial_effects_on_outcome(covariates = 'Treatment', values = [0, 1], plot_baseline=False, ax = ax2 )
    ax2.lines[0].set_color('k')
    ax2.lines[1].set_color('r')
    ax2.legend(['Treatment=0', 'Treatment=1', 'baseline'], fontsize = 12)
    ax2.set_xlabel('Time', fontsize =12)
    ax2.set_xlim(right = timeline)
    ax2.set_ylabel('Survival', fontsize = 12)
    
    fig2.savefig(path_figs+outcome+'_survSep2.pdf')

    summ = md.summary.round(3)
    if summary_names:
        summ.index = summary_names
    
    summ = summ[['coef','se(coef)', 'z','p']]
    summ.columns = ['Coefficient', 'Standard Error', 'z-statistic', 'p-value']
    summ.to_csv((path_tabs+outcome+'_summary.csv'))
    return logrank_summ, ax, ax2, summ
