from setuptools import setup
from Cython.Build import cythonize

setup(
    name='Controls app',
    ext_modules=cythonize("controls_cy.pyx"),
    zip_safe=False,
)