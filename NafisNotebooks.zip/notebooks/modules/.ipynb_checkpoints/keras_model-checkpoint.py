import tensorflow as tf
from tensorflow import keras
from numpy import loadtxt
import tensorflow.keras.backend as K
import matplotlib.pyplot as plt
import numpy as np

def unit_block(inp, out_dim, in_dim=None, bn=False, dr=False, dr_rate=0.5):
    _ = keras.layers.Dense(units=out_dim, kernel_regularizer=keras.regularizers.l2(l=0.2))(inp)
    _ = keras.layers.LeakyReLU(alpha=0.01)(_)
    if bn:
        _ = keras.layers.BatchNormalization(scale=True, center=True)(_)
    if dr:
        _ = keras.layers.Dropout(dr_rate)(_)
    return _

def plot_history(history, num_epochs, figsize):
    counter=0
    fig, axs = plt.subplots(int(len(history.history)/2), 1, figsize=figsize)
    for key in history.history.keys():
        if "val_" in key:
            train_key = key.split("val_",1)[1]
            val_key = "val_" + key.split("val_",1)[1]
            axs[counter].plot(np.arange(num_epochs),history.history.get(val_key), label='val')
            axs[counter].plot(np.arange(num_epochs), history.history.get(train_key), label='train')
            axs[counter].set_title(train_key + " VS " + val_key)
            axs[counter].set_xlabel("epochs")
            if 'loss' in key and val_key:
                axs[counter].set_ylabel("loss")
            else:
                axs[counter].set_ylabel("evaluation metric")
            axs[counter].legend()
            counter +=1

def make_model_1(input_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,))
    _ = unit_block(inp=input_layer, out_dim=128, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=64, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=32, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=16, activation='relu', bn=True, dr=True)
    representation_layer = keras.layers.Dense(units=8, name="representation")(_)
    
    # for allow amount -- regression
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    cost_output = keras.layers.Dense(units=1, name='cost_output')(_)

    # for total disease -- regression
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    dx_output = keras.layers.Dense(units=1, name='dx_output')(_)

    # for diabetes -- prediction
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    diabetes_output = keras.layers.Dense(units=1, activation='sigmoid', name='diabetes_output')(_)

    model = keras.models.Model(inputs=input_layer, outputs=[cost_output, dx_output, diabetes_output])
    model.compile(optimizer='adam',
                  loss={'cost_output': 'mae', 'dx_output': 'mae', 'diabetes_output': 'binary_crossentropy'},
                  loss_weights={'cost_output': 1.5, 'dx_output': 1.5, 'diabetes_output': 2},
                  metrics={'cost_output': 'mae', 'dx_output': 'mae', 'diabetes_output': 'accuracy'})
    
    return model

# -- extra: Model for ELX codes train
def make_model_2(input_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,)) #37
    _ = unit_block(inp=input_layer, out_dim=128, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=64, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=32, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=16, activation='relu', bn=True, dr=True)
    representation_layer = keras.layers.Dense(units=8, name="representation")(_)
    
    # for allow amount -- regression
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    cost_output = keras.layers.Dense(units=1, name='cost_output')(_)

    # for total disease -- regression
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    elx_cnt = keras.layers.Dense(units=1, name='elx_cnt')(_)

    # for diabetes -- prediction
    _ = keras.layers.Dense(units=32, activation='relu')(representation_layer)
    elx_score = keras.layers.Dense(units=1, name='elx_score')(_)

    model = keras.models.Model(inputs=input_layer, outputs=[cost_output, elx_cnt, elx_score])
    model.compile(optimizer='adam',
                  loss={'cost_output': 'mae', 'elx_cnt': 'mae', 'elx_score': 'mae'},
                  loss_weights={'cost_output': 1.5, 'elx_cnt': 1.5, 'elx_score': 2},
                  metrics={'cost_output': 'mae', 'elx_cnt': 'mae', 'elx_score': 'mae'})
    
    return model

# -- extra: Multi Task Model for ELX - all elx codes, each as separate tasks for optimization
def make_model_3(input_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,)) #37
    _ = unit_block(inp=input_layer, out_dim=128, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=64, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=32, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=16, activation='relu', bn=True, dr=True)
    representation_layer = keras.layers.Dense(units=8, name="representation")(_)
    
    #elx 17 is not present, total 30 output heads
    output_heads = []
    for i in range(31):
        layer_name = "elx_grp_" + str(i)
        if i!=16:
            elx_layer = keras.layers.Dense(units=1, activation="sigmoid", name=layer_name)(representation_layer)
            output_heads.append(elx_layer)
            
    #final model make
    model = keras.models.Model(inputs=input_layer, outputs=output_heads)
    model.compile(optimizer='adam',
                  loss="binary_crossentropy",
                  metrics=["accuracy"])
    
    return model
            
#model: for modeling future states of Metabolic Diseases
def make_model_4(input_shape, output_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,))
    _ = unit_block(inp=input_layer, out_dim=128, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=64, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=32, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=16, activation='relu', bn=True, dr=True)
    representation_layer = keras.layers.Dense(units=8, name="representation")(_)

    # for diabetes -- prediction
    metabolic_output = keras.layers.Dense(units=output_shape, activation='sigmoid', name='metabolic_output')(representation_layer)

    model = keras.models.Model(inputs=input_layer, outputs=metabolic_output)
    
    model.compile(optimizer='adam',
                  loss='binary_crossentropy',
                  metrics=["accuracy"])
    
    return model

#model: for modeling future states of Metabolic Diseases and health profile simultaneously
def make_model_5(input_shape, h_output_shape, m_output_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,))
    _ = unit_block(inp=input_layer, out_dim=128, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=64, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=32, activation='relu', bn=True, dr=True)
    _ = unit_block(inp=_, out_dim=16, activation='relu', bn=True, dr=True)
    representation_layer = keras.layers.Dense(units=8, name="representation")(_)

    # for allow amount -- regression
    _ = keras.layers.Dense(units=16, activation='relu')(representation_layer)
    health_output = keras.layers.Dense(units=h_output_shape, name='health_output')(_)
    
    # for diabetes -- prediction
    _ = keras.layers.Dense(units=16, activation='relu')(representation_layer)
    metabolic_output = keras.layers.Dense(units=m_output_shape, activation='sigmoid', name='metabolic_output')(_)

    model = keras.models.Model(inputs=input_layer, outputs=[health_output, metabolic_output])
    
    model.compile(optimizer='adam',
                  loss={'health_output': 'mae', 'metabolic_output': 'binary_crossentropy'},
                  loss_weights={'health_output': 1, 'metabolic_output': 1},
                  metrics={'health_output': 'mae', 'metabolic_output': 'accuracy'})
    
    return model
    
    
#model: autoencoder
def make_model_6(input_shape):
    
    input_layer = keras.layers.Input(shape=(input_shape,))
    _ = unit_block(inp=input_layer, out_dim=64, bn=False, dr=True)
    _ = unit_block(inp=_, out_dim=32, bn=False, dr=True)
    
    representation_layer = keras.layers.Dense(units=16, name="representation")(_)
    
    _ = unit_block(inp=representation_layer, out_dim=32, bn=False, dr=True)
    _ = unit_block(inp=_, out_dim=64, bn=False, dr=True)
    
    output_layer = keras.layers.Dense(units=input_shape, name="output")(_)

    model = keras.models.Model(inputs=input_layer, outputs=output_layer)
    
    model.compile(optimizer= keras.optimizers.Adam(clipnorm=1.0),
                 loss='mse')
    
    return model

