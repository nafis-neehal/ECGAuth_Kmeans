import numpy as np
import pandas as pd
from tqdm import tqdm

#with CC Codes
#for model 1
# Initially feature_grace = 6, label_grace = 2 for 12 month calculation respectively. Now we are having 6 month average.
def generate_data(pmpm, start_date, end_date, features, col_seq=None, feature_grace_months = 6, label_grace_months = 2):
    
    X = (pmpm.query("MYR>=@start_date & MYR<=@end_date")
        .sort_values(by=['PERS_ID','MYR'])
        .drop_duplicates(subset=['PERS_ID','MYR'])
        .replace({'MBR_GNDR': {'M':1, 'F':0}})
        .reset_index(drop=True)
    )
    #LABELS
    if features==False:
        size = X.groupby(by=['PERS_ID']).size().reset_index()
        size = size.loc[size[0]>=(size[0].max()-label_grace_months)] #column name of sizes is "0". choose those rows who have (max value - label_grace_months) in "0" column
        X = X.loc[X['PERS_ID'].isin(size.PERS_ID)] #take those IDs who have required frequencies
    
    #FEATURES
    else: #size matters for features
        size = X.groupby(by=['PERS_ID']).size().reset_index()
        size = size.loc[size[0]>=(size[0].max()-feature_grace_months)]
        X = X.loc[X['PERS_ID'].isin(size.PERS_ID)]
        
        size = X.groupby(by=['PERS_ID']).size().reset_index()
        size['weight'] = size[0]/size[0].max()

    disease_cols = [col for col in X.columns.tolist() if ('CC' in col) or ('ALLOW' in col)]
    A = pd.pivot_table(data=X,index="PERS_ID",values=disease_cols, aggfunc="mean")
    A.ALLOW_AMT = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_AMT'], aggfunc=np.mean).ALLOW_AMT
    A.ALLOW_IP = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_IP'], aggfunc=np.mean).ALLOW_IP
    A.ALLOW_ER = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_ER'], aggfunc=np.mean).ALLOW_ER
    
    if 'LOB' in col_seq:
        B = pd.pivot_table(data=X, index="PERS_ID", values=['MBR_GNDR', 'AGE_AT_MIDMONTH', 'LOB'], aggfunc="mean") #added IP_BIN6 and ER_BIN6 here
    else:
        B = pd.pivot_table(data=X, index="PERS_ID", values=['MBR_GNDR', 'AGE_AT_MIDMONTH'], aggfunc="mean")#added IP_BIN6 and ER_BIN6 here
        
#     B.IP_BIN6  = X.groupby('PERS_ID').last().IP_BIN6
#     B.ER_BIN6  = X.groupby('PERS_ID').last().ER_BIN6
    
    X = B.merge(A, how='left', on='PERS_ID')
    X = X.reset_index()
    X = X[col_seq]
    X = X.dropna()

    return X, size

#for model 2 and model 3
def generate_data2(pmpm, start_date, end_date, features, label_cols=None, col_seq=None):
    X = (pmpm.query("MYR>=@start_date & MYR<=@end_date & PERS_ID>'0'")
        .sort_values(by=['PERS_ID','MYR'])
        .drop_duplicates(subset=['PERS_ID','MYR'])
        .replace({'MBR_GNDR': {'M':0, 'F':1}})
    )
    
    disease_cols = [col for col in X.columns.tolist() if ('ELX' in col) or ('ALLOW' in col) or ("ELIX" in col) and (col!="ELX_SCORE")]
    
    A = pd.pivot_table(data=X,index="PERS_ID",values=disease_cols, aggfunc="sum")
    
    if(features):
        A.ALLOW_AMT = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_AMT'], aggfunc=np.median).ALLOW_AMT
        
        #--extra
        A.ALLOW_IP = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_IP'], aggfunc=np.median).ALLOW_IP
        A.ALLOW_ER = pd.pivot_table(data=X,index="PERS_ID",values=['ALLOW_ER'], aggfunc=np.median).ALLOW_ER
        A.ELX_SCORE = pd.pivot_table(data=X,index="PERS_ID",values=['ELX_SCORE'], aggfunc=np.mean).ELX_SCORE
        A.ELIXHAUSER = pd.pivot_table(data=X,index="PERS_ID",values=['ELIXHAUSER'], aggfunc=np.mean).ELIXHAUSER.apply(np.round)
        #--extra
        
    B = pd.pivot_table(data=X, index="PERS_ID", values=['AGE_AT_MIDMONTH', 'MBR_GNDR'], aggfunc="max")
    
    X = B.merge(A, how='left', on='PERS_ID')
    
    if(features) and (col_seq):
        #-- extra (delete uncommented line, comment out commented line - reverted back) 
        X = X.reset_index()
        X = X[col_seq]
        #X = X.query("CC_DIABETES==0").reset_index()
        #-- extra
        
    if(not features) and (label_cols):
        X = X[label_cols].reset_index()
    
    return X


def make_intersection(train_X, train_Y):
    commonPMPM = np.intersect1d(train_X.PERS_ID, train_Y.PERS_ID)
    train_X = train_X[train_X.PERS_ID.isin(commonPMPM)]
    train_Y = train_Y[train_Y.PERS_ID.isin(commonPMPM)]
    return train_X, train_Y