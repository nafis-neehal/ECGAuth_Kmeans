import numpy as np
import pandas as pd
import scipy.stats as sts
#from utils_cy import cumsum_past
from data_functions import make_date_to_MYR



def statistics_first_month(df, columns_to_match, return_array = False):
    """
    Compute the statistics on the first month of data
    of the dataframe df on the columns_to_match
    returns the mean and std of the statistics as well as the size of the dataframe
    
    """
    df = df.sort_values(by = ['PERS_ID', 'MYR'])
    df = df.groupby('PERS_ID').apply(lambda x: pd.Series(x.iloc[0])).reset_index(drop = True)
    
    if return_array:
        desc_stats = df[columns_to_match].describe().loc[['mean','std','count']].T
        desc_stats['count'] = desc_stats['count'].astype(int)
        return desc_stats.T, desc_stats['count'][0], df[columns_to_match]
    else:
        desc_stats = df[columns_to_match].describe().loc[['mean','std','count']].T
        desc_stats['count'] = desc_stats['count'].astype(int)
        return desc_stats.T, desc_stats['count'][0]

def p_val(stats1, stats2):
    """
    receives two description panda arrays
    with mean, std and count
    and returns t-stat and p-value
    
    """
    args = {'mean1':stats1['mean'], 'std1':stats1['std'], 'mean2':stats2['mean'], 'std2':stats2['std'], 'nobs1': stats1['count'].values , 'nobs2': stats2['count'].values}
    stats, pval = sts.ttest_ind_from_stats(**args)
    stats = pd.DataFrame(stats, columns = ['t-stat'])
    stats['pval'] = pval
    
    return stats

def stat_matrices(desc_treated, desc_controls, desc_general, desc_random, columns = None):
    
    """
    takes the stat matrices for controls treated general population and random
    computes tstats and p values and returns a condensend and a full matrix with the stats
    with the chosen columns
    
    """
    
    pvalTC = p_val(desc_treated, desc_controls)
    pvalTG = p_val(desc_treated, desc_general)
    pvalTR = p_val(desc_treated, desc_random)
    
    condensed_stats = pd.concat((desc_treated['mean'],
                                desc_controls['mean'],
                                pvalTC,
                                desc_general['mean'],
                                desc_random['mean']), 
                                axis = 1, 
                                keys = ['Treated', 'Matched Controls',
                                        'Test-TC', 'General Population', 'Random'] )
    
    full_stats = pd.concat((desc_treated,
                            desc_controls,
                            pvalTC,
                            desc_general,
                            pvalTG,
                            desc_random,
                            pvalTR), 
                            axis = 1,
                            keys = ['Treated', 'Matched Controls',
                                    'Test-TC', 'General Population',
                                    'Test-TG', 'Random', 'Test-TR'] )
    if not columns:
        return condensed_stats, full_stats
    else:
        return condensed_stats.loc[columns], full_stats.loc[columns]
    s

def ip_er(group):
    x = np.arange(len(group))+1
    group['AVG_IP'] = (group.ALLOW_IP > 0).cumsum()/x
    group['AVG_ER'] = (group.ALLOW_ER > 0).cumsum()/x
    return group

def ip_er2(group, time):
    x = min(len(group), time)
    c1 = group.IP_BIN.cumsum()
    c2 = group.ER_BIN.cumsum()
    group.loc[:,'IP_BIN2'] = c1.values-c1.shift(periods = x, fill_value =0).values
    group.loc[:,'ER_BIN2'] = c2.values-c2.shift(periods = x, fill_value =0).values
    group['IP_C'] = c1
    group['ER_C'] = c2
    
    return group


def ip_er2cy(group, time):
    group[['IP_BIN2', 'ER_BIN2']] = cumsum_past(group[['IP_BIN', 'ER_BIN']].astype(int).values, len(group), time)
    return group
        

##### GAP DATA STATS
def datecols(dat):
    """
    Make MYR to date
    
    """
    dat['YEAR'] = (dat.MYR//100).astype(int)
    dat['MONTH'] = (dat.MYR%100).astype(int)
    dat['DAY'] = 1
    dat['DATE'] = pd.to_datetime(dat[['YEAR', 'MONTH', 'DAY']])
    return dat

def timestats(dat):
    """
    Length: Number of data points per ID
    Months: Number of Months between Last Month and First Month (this should the same as Length for good data)
    Mean Gap: When data are not consecutive what is the average Gap between months
    Max Gap: the maximum Gap in an Patient
    DIFF: Difference between month span and month points
    
    """
    dat['DELTA'] = (dat.groupby('PERS_ID')['DATE'].diff()/np.timedelta64(1, 'M')).round()
    dat.dropna(inplace = True)
    dat.reset_index(drop = True, inplace = True)
    time_stats= dat.groupby('PERS_ID').apply(lambda x: pd.Series([len(x), ((x.DATE.iloc[-1]-x.DATE.iloc[0])/np.timedelta64(1, 'M'))+1,
                                                                  (x.DELTA-1).mean(), (x.DELTA-1).max()],
                                                    index = ['Length', 'Months','Mean Gap', 'Max Gap'])).reset_index()
    
    time_stats.Months = time_stats.Months.round()
    time_stats['DIFF'] = np.abs(time_stats.Length.values-time_stats.Months.values)
    return time_stats

def aggregate_time_stats(dat):
    """
    Mean DIFF: Mean difference of the differences between time points and months
    Mean Mean Gap: the mean of the mean of the Gaps across all patients
    #Patients with Non Zero Gap: as the name suggests
    'Mean Gap Fof Patients with Non Zero Gap'
    
    """
    dat['Mean DIFF'] = dat.DIFF.mean()
    dat['Mean Mean Gap'] = dat['Mean Gap'].mean()
    dat['#Patients with Non Zero Gap'] = len(dat[dat['Max Gap'] >0])
    dat['Mean Gap For Patients with Non Zero Gap'] = dat[dat['Max Gap']>0]['Mean Gap'].mean()
    return dat


def combine_above_three(dat):
    dat = datecols(dat.copy())
    dat = timestats(dat.copy())
    dat = aggregate_time_stats(dat.copy())
    return dat


def findDate(dat, dat2,  past_months):
    
    first = dat[['PERS_ID', 'MYR']].groupby('PERS_ID').apply(lambda x : x.iloc[0]).reset_index(drop = True)
    first['year'] = (first.MYR//100).astype(int)
    first['month'] = (first.MYR%100).astype(int)
    first['day'] = 1
    first['REG_DATE'] = pd.to_datetime(first[['year','month','day']])
    first['PAST_DATE'] = (first.REG_DATE - pd.DateOffset(months = past_months)).apply(make_date_to_MYR)
    first['PAST_DATE0'] = (first.REG_DATE - pd.DateOffset(months = past_months+1)).apply(make_date_to_MYR)
    first['PAST_DATE00'] = (first.REG_DATE - pd.DateOffset(months = past_months+2)).apply(make_date_to_MYR)

    first['PAST_DATE1'] = (first.REG_DATE - pd.DateOffset(months = past_months-1)).apply(make_date_to_MYR)
    first['PAST_DATE2'] = (first.REG_DATE - pd.DateOffset(months = past_months-2)).apply(make_date_to_MYR)
    first['PAST_DATE3'] = (first.REG_DATE - pd.DateOffset(months = past_months-3)).apply(make_date_to_MYR)


    first['REG_DATE'] = first['REG_DATE'].apply(make_date_to_MYR)
    first = first[['PERS_ID',  'REG_DATE', 'PAST_DATE','PAST_DATE00', 'PAST_DATE0', 'PAST_DATE1', 'PAST_DATE2', 'PAST_DATE3']]
    dat2['PERS_ID'] = dat2.PERS_ID.astype(int)
    first['PERS_ID'] = first.PERS_ID.astype(int)

    dat3 =  dat2.merge(first, how = 'right', on = 'PERS_ID')
    dat3['IN_STUDY'] = 0
   # dat2['PERS_ID'] = dat2.PERS_ID.astype(int)
   # dat['PERS_ID'] = dat.PERS_ID.astype(int)

   # dat_all_months = dat2.merge(dat['PERS_ID','REG', how = 'right', on = 'PERS_ID')
    return dat3

def firstdate(group):
    date = group['PAST_DATE'].iloc[0]
    date3 = group['PAST_DATE3'].iloc[0]
    date2 = group['PAST_DATE2'].iloc[0]
    date1 = group['PAST_DATE1'].iloc[0]
    date0 = group['PAST_DATE0'].iloc[0]
    date00 = group['PAST_DATE00'].iloc[0]

    dates = group.MYR.unique()
    #if (date in dates) or (date1 in dates) or (date0 in dates) or (date2 in dates) or (date00 in dates) or (date3 in dates) :
    if date in dates:
        group = group[group.MYR >= date]
        group['IN_STUDY'] = 1
    return group

def filter_first_date(data):
    data = data.groupby('PERS_ID').apply(firstdate)
    filt = data['IN_STUDY'] == 1
    data = data[filt].reset_index(drop = True)
    return data
    
    
    