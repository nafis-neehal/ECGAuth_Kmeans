## Edit Paths
'''
All local paths are paths in cluster disk space. All AWS paths are keys from S3.
data_path = local folder where data will be downloaded 
temp_path = where downloaded files are usually saved after they are processed 
canary_aws_path = S3 Key of Canary Source file in Step 1 
canary_local_path = local path where Canary will be saved after pulled from S3 in Step 1
biometrics_aws_path = S3 Key of Biometrics Source file in Step 1 
biometrics_local_path = local path where Biometrics will be saved after pulled from S3 in Step 1
pmpm_aws_path = S3 Key of Original PMPM Source file in Step 1 
pmpm_local_path = local path where Original PMPM will be saved after pulled from S3 in Step 1 
pmpm_eligible_aws_path = S3 Key where processed PMPM is stored after Step 2 (for easy loading while experimenting, otherwise takes a long time) 
pmpm_eligible_local_path = local path where processed PMPM is stored after pulling from S3 in Step 1 (if it was already processed before and saved in S3 for faster loading)
generated_causal_data_path = saved causal data after merging Biometrics, PMPM and Canary data -> feed to DoWhy/CEM
'''

from pathlib import Path
path = str(Path.home()) + '/rpi-canary-eval'

path_dict = {
    'data_path': path +'/data',
    'temp_path': path + '/temp',
    'aws_bucket':'cdphp-s3-us-e-p-pond',
    'canary_aws_path': 's3://cdphp-s3-us-e-p-pond/rpi/DataSources/PROGRAMS/CANARY/CANARY202108',
    'canary_local_path': path + '/data/CANARY',
    'biometrics_aws_path': 's3://cdphp-s3-us-e-p-pond/rpi/DataSources/BIOMETRICS202108/',
    'biometrics_local_path': path + '/data/BIOMETRICS',
    'pmpm_aws_path': 's3://cdphp-s3-us-e-p-pond/rpi/DataSources/FROM_LAKE/PMPM/ANALYTIC_PMPM202108',
    'pmpm_local_path': path + '/data/PMPM',
    'pmpm_processed_aws_path': 'rpi/nneehal/DATA/CC_ELIGIBLE.p',
    'pmpm_processed_local_path': path + '/temp/CC_PMPM.p',
    'generated_causal_data_path': path + '/temp/CAUSAL_ELX.p'
}

#-------------------------------------------------------------------------------------------------
#Column sequences

col_seq_cc= ['PERS_ID', 'AGE_AT_MIDMONTH', 'MBR_GNDR', 'ALLOW_AMT', 'ALLOW_ER', 'ALLOW_IP', 'CC_ADHD',
       'CC_ALZHEIMER', 'CC_ALZHEIMER_PLUS', 'CC_AMI', 'CC_ANEMIA',
       'CC_ANXIETY_DISORDER', 'CC_ARTHRITIS', 'CC_ASTHMA', 'CC_ATRIAL_FIB',
       'CC_AUTISM', 'CC_BIPOLAR', 'CC_BPH', 'CC_BREAST_CANCER', 'CC_CATARACT',
       'CC_CEREBRAL_PALSY', 'CC_CHRONIC_KIDNEY', 'CC_COLORECTAL_CANCER',
       'CC_COPD', 'CC_CYSTIC_FIBROSIS', 'CC_DEPRESSION',
       'CC_DEPRESSIVE_DISORDERS', 'CC_DEVELOP_DELAYS', 'CC_DIABETES',
       'CC_DISAB_DX_CNT', 'CC_DX_CNT', 'CC_ENDOMETRIAL_CANCER', 'CC_EPILEPSY',
       'CC_FIBROMYALGIA', 'CC_GLAUCOMA', 'CC_HEARING_IMPAIR',
       'CC_HEART_FAILURE', 'CC_HEPATITIS_A', 'CC_HEPATITIS_B_ACUTE',
       'CC_HEPATITIS_B_CHRONIC', 'CC_HEPATITIS_C_ACUTE',
       'CC_HEPATITIS_C_CHRONIC', 'CC_HEPATITIS_C_UNSPECIFIED',
       'CC_HEPATITIS_D', 'CC_HEPATITIS_E', 'CC_HEPATITIS_GEN',
       'CC_HIP_FRACTURE', 'CC_HYPERLIPIDEMIA', 'CC_HYPERTENSION',
       'CC_HYPOTHYROID', 'CC_INT_DISAB', 'CC_ISCHEMIC', 'CC_LEARN_DISAB',
       'CC_LEUKEMIAS', 'CC_LIVER', 'CC_LUNG_CANCER', 'CC_MIGRAINE',
       'CC_MOBILITY_IMPAIR', 'CC_MULTIPLE_SCLEROSIS', 'CC_MUSCULAR_DYSTROPHY',
       'CC_OBESITY', 'CC_OSTEOPOROSIS', 'CC_PERIPHERAL', 'CC_PERSONALITY',
       'CC_PRESSURE', 'CC_PROSTATE_CANCER', 'CC_PTSD', 'CC_SCHIZOPHRENIA',
       'CC_SCHIZOPHRENIA_OTHER', 'CC_SPINAL_CORD', 'CC_SPINA_BIFIDA',
       'CC_STROKE', 'CC_TOBACCO', 'CC_TRAUMATIC_BRAIN', 'CC_VISUAL_IMPAIR']

col_seq_can= ['PERS_ID', 'AGE_AT_MIDMONTH', 'LOB', 'MBR_GNDR', 'ALLOW_AMT', 'ALLOW_ER', 'ALLOW_IP', 'CC_ADHD',
       'CC_ALZHEIMER', 'CC_ALZHEIMER_PLUS', 'CC_AMI', 'CC_ANEMIA',
       'CC_ANXIETY_DISORDER', 'CC_ARTHRITIS', 'CC_ASTHMA', 'CC_ATRIAL_FIB',
       'CC_AUTISM', 'CC_BIPOLAR', 'CC_BPH', 'CC_BREAST_CANCER', 'CC_CATARACT',
       'CC_CEREBRAL_PALSY', 'CC_CHRONIC_KIDNEY', 'CC_COLORECTAL_CANCER',
       'CC_COPD', 'CC_CYSTIC_FIBROSIS', 'CC_DEPRESSION',
       'CC_DEPRESSIVE_DISORDERS', 'CC_DEVELOP_DELAYS', 'CC_DIABETES',
       'CC_DISAB_DX_CNT', 'CC_DX_CNT', 'CC_ENDOMETRIAL_CANCER', 'CC_EPILEPSY',
       'CC_FIBROMYALGIA', 'CC_GLAUCOMA', 'CC_HEARING_IMPAIR',
       'CC_HEART_FAILURE', 'CC_HEPATITIS_A', 'CC_HEPATITIS_B_ACUTE',
       'CC_HEPATITIS_B_CHRONIC', 'CC_HEPATITIS_C_ACUTE',
       'CC_HEPATITIS_C_CHRONIC', 'CC_HEPATITIS_C_UNSPECIFIED',
       'CC_HEPATITIS_D', 'CC_HEPATITIS_E', 'CC_HEPATITIS_GEN',
       'CC_HIP_FRACTURE', 'CC_HYPERLIPIDEMIA', 'CC_HYPERTENSION',
       'CC_HYPOTHYROID', 'CC_INT_DISAB', 'CC_ISCHEMIC', 'CC_LEARN_DISAB',
       'CC_LEUKEMIAS', 'CC_LIVER', 'CC_LUNG_CANCER', 'CC_MIGRAINE',
       'CC_MOBILITY_IMPAIR', 'CC_MULTIPLE_SCLEROSIS', 'CC_MUSCULAR_DYSTROPHY',
       'CC_OBESITY', 'CC_OSTEOPOROSIS', 'CC_PERIPHERAL', 'CC_PERSONALITY',
       'CC_PRESSURE', 'CC_PROSTATE_CANCER', 'CC_PTSD', 'CC_SCHIZOPHRENIA',
       'CC_SCHIZOPHRENIA_OTHER', 'CC_SPINAL_CORD', 'CC_SPINA_BIFIDA',
       'CC_STROKE', 'CC_TOBACCO', 'CC_TRAUMATIC_BRAIN', 'CC_VISUAL_IMPAIR', 'LOB', 'PREGNANCY',
       'IP_BIN', 'ER_BIN','ACUTE','IP_C', 'ER_C', 'ACUTE_C', 'IP_BIN6', 'ER_BIN6', 'ACUTE6', 'IP_BIN2', 'ER_BIN2', 'ACUTE2']

col_seq_can_all= ['PERS_ID', 'MYR', 'AGE_AT_MIDMONTH', 'LOB', 'MBR_GNDR', 'ALLOW_AMT', 'ALLOW_ER', 'ALLOW_IP', 'CC_ADHD',
       'CC_ALZHEIMER', 'CC_ALZHEIMER_PLUS', 'CC_AMI', 'CC_ANEMIA',
       'CC_ANXIETY_DISORDER', 'CC_ARTHRITIS', 'CC_ASTHMA', 'CC_ATRIAL_FIB',
       'CC_AUTISM', 'CC_BIPOLAR', 'CC_BPH', 'CC_BREAST_CANCER', 'CC_CATARACT',
       'CC_CEREBRAL_PALSY', 'CC_CHRONIC_KIDNEY', 'CC_COLORECTAL_CANCER',
       'CC_COPD', 'CC_CYSTIC_FIBROSIS', 'CC_DEPRESSION',
       'CC_DEPRESSIVE_DISORDERS', 'CC_DEVELOP_DELAYS', 'CC_DIABETES',
       'CC_DISAB_DX_CNT', 'CC_DX_CNT', 'CC_ENDOMETRIAL_CANCER', 'CC_EPILEPSY',
       'CC_FIBROMYALGIA', 'CC_GLAUCOMA', 'CC_HEARING_IMPAIR',
       'CC_HEART_FAILURE', 'CC_HEPATITIS_A', 'CC_HEPATITIS_B_ACUTE',
       'CC_HEPATITIS_B_CHRONIC', 'CC_HEPATITIS_C_ACUTE',
       'CC_HEPATITIS_C_CHRONIC', 'CC_HEPATITIS_C_UNSPECIFIED',
       'CC_HEPATITIS_D', 'CC_HEPATITIS_E', 'CC_HEPATITIS_GEN',
       'CC_HIP_FRACTURE', 'CC_HYPERLIPIDEMIA', 'CC_HYPERTENSION',
       'CC_HYPOTHYROID', 'CC_INT_DISAB', 'CC_ISCHEMIC', 'CC_LEARN_DISAB',
       'CC_LEUKEMIAS', 'CC_LIVER', 'CC_LUNG_CANCER', 'CC_MIGRAINE',
       'CC_MOBILITY_IMPAIR', 'CC_MULTIPLE_SCLEROSIS', 'CC_MUSCULAR_DYSTROPHY',
       'CC_OBESITY', 'CC_OSTEOPOROSIS', 'CC_PERIPHERAL', 'CC_PERSONALITY',
       'CC_PRESSURE', 'CC_PROSTATE_CANCER', 'CC_PTSD', 'CC_SCHIZOPHRENIA',
       'CC_SCHIZOPHRENIA_OTHER', 'CC_SPINAL_CORD', 'CC_SPINA_BIFIDA',
       'CC_STROKE', 'CC_TOBACCO', 'CC_TRAUMATIC_BRAIN', 'CC_VISUAL_IMPAIR', 'LOB', 'PREGNANCY',
       'IP_BIN', 'ER_BIN','ACUTE','IP_C', 'ER_C', 'ACUTE_C', 'IP_BIN6', 'ER_BIN6', 'ACUTE6', 'IP_BIN2', 'ER_BIN2', 'ACUTE2']


col_seq_cc_all= ['PERS_ID', 'MYR', 'AGE_AT_MIDMONTH', 'MBR_GNDR', 'ALLOW_AMT', 'ALLOW_ER', 'ALLOW_IP', 'CC_ADHD',
       'CC_ALZHEIMER', 'CC_ALZHEIMER_PLUS', 'CC_AMI', 'CC_ANEMIA',
       'CC_ANXIETY_DISORDER', 'CC_ARTHRITIS', 'CC_ASTHMA', 'CC_ATRIAL_FIB',
       'CC_AUTISM', 'CC_BIPOLAR', 'CC_BPH', 'CC_BREAST_CANCER', 'CC_CATARACT',
       'CC_CEREBRAL_PALSY', 'CC_CHRONIC_KIDNEY', 'CC_COLORECTAL_CANCER',
       'CC_COPD', 'CC_CYSTIC_FIBROSIS', 'CC_DEPRESSION',
       'CC_DEPRESSIVE_DISORDERS', 'CC_DEVELOP_DELAYS', 'CC_DIABETES',
       'CC_DISAB_DX_CNT', 'CC_DX_CNT', 'CC_ENDOMETRIAL_CANCER', 'CC_EPILEPSY',
       'CC_FIBROMYALGIA', 'CC_GLAUCOMA', 'CC_HEARING_IMPAIR',
       'CC_HEART_FAILURE', 'CC_HEPATITIS_A', 'CC_HEPATITIS_B_ACUTE',
       'CC_HEPATITIS_B_CHRONIC', 'CC_HEPATITIS_C_ACUTE',
       'CC_HEPATITIS_C_CHRONIC', 'CC_HEPATITIS_C_UNSPECIFIED',
       'CC_HEPATITIS_D', 'CC_HEPATITIS_E', 'CC_HEPATITIS_GEN',
       'CC_HIP_FRACTURE', 'CC_HYPERLIPIDEMIA', 'CC_HYPERTENSION',
       'CC_HYPOTHYROID', 'CC_INT_DISAB', 'CC_ISCHEMIC', 'CC_LEARN_DISAB',
       'CC_LEUKEMIAS', 'CC_LIVER', 'CC_LUNG_CANCER', 'CC_MIGRAINE',
       'CC_MOBILITY_IMPAIR', 'CC_MULTIPLE_SCLEROSIS', 'CC_MUSCULAR_DYSTROPHY',
       'CC_OBESITY', 'CC_OSTEOPOROSIS', 'CC_PERIPHERAL', 'CC_PERSONALITY',
       'CC_PRESSURE', 'CC_PROSTATE_CANCER', 'CC_PTSD', 'CC_SCHIZOPHRENIA',
       'CC_SCHIZOPHRENIA_OTHER', 'CC_SPINAL_CORD', 'CC_SPINA_BIFIDA',
       'CC_STROKE', 'CC_TOBACCO', 'CC_TRAUMATIC_BRAIN', 'CC_VISUAL_IMPAIR']

col_seq_elx = ['PERS_ID', 'AGE_AT_MIDMONTH','MBR_GNDR','ALLOW_AMT','ALLOW_ER','ALLOW_IP','ELIXHAUSER','ELX_GRP_1', 'ELX_GRP_2', 'ELX_GRP_3', 'ELX_GRP_4', 'ELX_GRP_5','ELX_GRP_6','ELX_GRP_7','ELX_GRP_8','ELX_GRP_9', 'ELX_GRP_10','ELX_GRP_11','ELX_GRP_12','ELX_GRP_13','ELX_GRP_14','ELX_GRP_15','ELX_GRP_16','ELX_GRP_18', 'ELX_GRP_19','ELX_GRP_20','ELX_GRP_21','ELX_GRP_22','ELX_GRP_23','ELX_GRP_24', 'ELX_GRP_25','ELX_GRP_26','ELX_GRP_27','ELX_GRP_28','ELX_GRP_29','ELX_GRP_30','ELX_GRP_31', 'ELX_SCORE']

label_cols_elx = ['ELX_GRP_1', 'ELX_GRP_2', 'ELX_GRP_3',
       'ELX_GRP_4', 'ELX_GRP_5', 'ELX_GRP_6', 'ELX_GRP_7', 'ELX_GRP_8',
       'ELX_GRP_9', 'ELX_GRP_10', 'ELX_GRP_11', 'ELX_GRP_12', 'ELX_GRP_13',
       'ELX_GRP_14', 'ELX_GRP_15', 'ELX_GRP_16', 'ELX_GRP_18', 'ELX_GRP_19',
       'ELX_GRP_20', 'ELX_GRP_21', 'ELX_GRP_22', 'ELX_GRP_23', 'ELX_GRP_24',
       'ELX_GRP_25', 'ELX_GRP_26', 'ELX_GRP_27', 'ELX_GRP_28', 'ELX_GRP_29',
       'ELX_GRP_30', 'ELX_GRP_31']