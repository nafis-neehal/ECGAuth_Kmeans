import pandas as pd
import numpy as np
import time
import datetime as dt

# #cython imports
# from controls_cy import make_cy

#HELPER FUNCTIONS RELATED TO DATE FORMATTING
def make_days1( row ):
    """
    takes a datetime.date
    object and makes the day 1
    """
    year = row.year
    month = row.month
    
    return dt.date(year = year, month = month, day = 1)

def datetime_to_days(group):
    """
    transforms a date into the total
    number of days 
    assuming a year is 365 days and
    a month 30 days
    
    """
    
    days = group.year*365 + group.month*30 + group.day
    return days

def make_date_to_MYR( row ):
    """
    takes a datetime.date object
    and returns a 6 digit integer
    year-month, ex:1993-02-01-->199302
    
    """
    
    new_row = row.year*100 +row.month
    
    return new_row

def make_MYR_to_date( row ):
    """
    takes a MYR int and converts it to
    datetime.date object
    
    """
    year = int(row/100)
    month  = int(row%100)
    
    return dt.date(year = year, month = month, day = 1)


#HELPER FUNCTIONS FOR CONTINUOUS ENROLLMENT CRITERIA
def is_consecutive(date1, date2):
    """
    Checks if two dates in
    YYYYMM format are consecutive
    for example 
    date1 = 201809, date2 = 201810--> True
    date1 = 201812, date2 = 201901 -->True
    date1 = 201708, date2 = 201710 --> False
    
    """
    
    m1, y1 = date1%100, date1//100
    m2, y2 = date2%100, date2//100
    
    if m2%12 == (m1%12 + 1):
        if (y1 == y2) or (y2 == y1+1):
            return True
        
    if (m1 == 11) and (m2 == 12):
        if (y1 == y2) or (y2 == y1+1):
            return True
        
    
    return False
    
def enrollement_check( data, time_in_months):
    """
    Finds All Patients with Continuous Enrollement
    data in a Nx2 matrix, N is the size of PMPM
    columns: 1:ids, 2:Myr, 
    
    data: Nx2 matrix first column is the patients Ids
    second column is the time in months that a patient
    needs to be enrolled consecutively
    """
    
    tm = time_in_months
    
    #first patient id to check
    current_id = data[0,0]
    counter = 1
    
    #corresponding year month date
    current_date = data[0,1]
    start_date = current_date
    N = data.shape[0]
    enhanced_data = []
    
    #for all dates and ids in dataset
    for i in range(1,N):
        idi = data[i, 0]
        date_i = data[i, 1]
        
        if idi == current_id: #we still checking a specific patient
            if is_consecutive(current_date, date_i):
                counter += 1
            else:
                if counter >= tm:
                    enhanced_data.append([current_id, start_date, current_date, counter])
                
                counter = 1
                start_date = date_i
        
        else: #change id
            if counter >= tm: #if previous id was satisfying enrollment criteria
                enhanced_data.append([current_id, start_date, current_date, counter])
           

            
            #reseting start date
            start_date = date_i
            
            #reseting counter
            counter = 1
        
        #prepare date and id for next iteration
        current_date = date_i
        current_id = idi
        
    return enhanced_data

#entry point for enrollemnet filter returns a panda array
def customize_data(data, time_in_months):
    """
    data: Nx2 matrix where first column is the ids and second 
    column the corresponding yearmonth
    """
    dat = enrollement_check(data, time_in_months)
    
    columns = ['PERS_ID', 'FIRST_DATE', 'LAST_DATE', 'MONTH_COUNTER']
    
    return pd.DataFrame(dat, columns = columns)
    
def enrollement_filter(pmpm, time_in_months):
    """
    Apply enrollement criteria filter in pmpm
    
    """
    #sort values by id and yearmonth
    pmpm.sort_values(by = ['PERS_ID', 'MYR'], inplace = True)
    
    #reset the index
    pmpm.reset_index(drop = True, inplace = True)
    
    #get just the Person Ids and MYR columns
    pmpm_test = pmpm[['PERS_ID', 'MYR']].values
    
    #apply enrollement criteria
    dat = customize_data(pmpm_test, time_in_months)
    
    #keep only ids that satisfy the continuous enrollement criteria
    unique_ids = dat.PERS_ID.unique()
    pmpm = pmpm[pmpm.PERS_ID.isin(unique_ids)].reset_index(drop=True)
    
    return pmpm

#HELPER for dropping the last data point in a group
def drop_last(group):
    return group.iloc[0:-1]


#HELPER for filtering pandas arrays for outcomes for treated patients 
#on canary #DO NOT USE THIS FUNCTION USE --> pick_covariates2
def pick_covariates( group ):
    """
    choses rows closer 
    to registration and last activity date
    
    deprecated: USE pick_covariates2
    """
    indx_start = np.argmin(group['REF_START'].values)
    indx_end   = np.argmin(group['REF_END'].values)
    N = len(group) - 1
    if indx_start == indx_end:
        if indx_start != N:
            indx_end = N
        else:
            indx_start = 0
    measure_start = group.iloc[indx_start].EVENT_DATE
    measure_end   = group.iloc[indx_end].EVENT_DAE
            
    data = group.iloc[[indx_start, indx_end]]    
    data['FF'] = 0
    data.iloc[1,-1] = 1
    data['OUTCOME'] = int((data['RESULT_VALUE'].iloc[-1] - data['RESULT_VALUE'].iloc[0])<0)
    data['OUTCOME2']  = (data['RESULT_VALUE'].iloc[-1] - data['RESULT_VALUE'].iloc[0])/data['RESULT_VALUE'].iloc[0]
    return data
        
### A SECOND MOST SEVERE FILTERING ON ACQUIRING TREATED OUTCOMES     
def pick_covariates2(group, days_pre, days_post, threshold = 0,
                     bigger_better = False, window = 3):
    """
    more strict criteria on acquiring covariates and outcomes
    group: group that the filtering will occur
    days_pre: How many days at most before registartion
    we are allowed to record features
    days_post: how many days after last activity date at most we are allowed to record
    features
    threshold: above this the results value is considered good(bigger_better = True) or bad (bigger_better = False)
    bigger_better: if a value above threshold is considered good or bad
    window: months to propagate forward  the results values
    
    """
    group['RESULT_VALUE'] = group.groupby(by = ['PERS_ID']).RESULT_VALUE.fillna(method = 'ffill', limit = window)

    if bigger_better:
        group['RESULT_VALUE2'] = (group.RESULT_VALUE >= threshold).astype(int)
    else:
        group['RESULT_VALUE2'] = (group.RESULT_VALUE <= threshold).astype(int)
    
    #Results value 2 gets 1 if it was null
    group.loc[group.RESULT_VALUE.isnull(), 'RESULT_VALUE2'] = 1
   
    #get only measuremnts before register date
    start_dates = group.EVENT_DATE <= group.REGISTER_DATE
    
    #get only measurements after last activity date
    end_dates = group.EVENT_DATE >= group.LAST_ACTIVITY_DATE
    
    #group eligible for pre register date covariates
    group_st = group[start_dates]
    
    #require start data at most days_pre days before register date
    group_st = group_st[group_st['REF_START'].dt.days <= days_pre]
    
    ####### ATTENTION MODIFY THIS FOR MORE GENERALITY
    if not group_st.empty: #if no dates find return NULL 
        group_st = group_st.sort_values(by = 'REF_START').iloc[0]
    else:
        return
    
    #now for the end dates
    group_en = group[end_dates]
    
    #require end data at least days_pre days after last activity date and at most days_post days
    #differentiate the cases where register and end date are identical or not
    if group.REGISTER_DATE.iloc[0] != group.LAST_ACTIVITY_DATE.iloc[0]: #if the two dates are different then allow at most days_post after end date for measuremnt
        group_en = group_en[(group_en['REF_END'].dt.days <= days_post) & (group_en['REF_END'].dt.days >= 0)  ]
    else:
        #if dates are the same require at least 120 days diffence
        group_en = group_en[(group_en['REF_END'].dt.days <= days_post) & (group_en['REF_END'].dt.days >= days_pre)  ]
   
    if not group_en.empty:
        group_en = group_en.sort_values(by = 'REF_END').iloc[0]
    else:
        return
    
    #group.st is a series so its index are the columns of the dataframe
    data = pd.DataFrame((group_st.values, group_en.values), columns = group_st.index)
    data['FF'] = 0
    data.iloc[1,-1] = 1
    data['OUTCOME'] = int((data['RESULT_VALUE'].iloc[-1] - data['RESULT_VALUE'].iloc[0])<0)
    data['OUTCOME2']  = (data['RESULT_VALUE'].iloc[-1] - data['RESULT_VALUE'].iloc[0])/data['RESULT_VALUE'].iloc[0]
    data['OUTCOME3']  = int(data['RESULT_VALUE2'].iloc[-1] - data['RESULT_VALUE2'].iloc[0])
    data.OUTCOME3 = data.OUTCOME3.replace(to_replace={0:1, 1:1, -1:0})
    
    
    return data

#----------------------- BIOMETRICS-----------------------------------
#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________

def bio_processing(biometrics):
    """
     -----Biometrics data processing-----
    1)Makes PERS_ID from string integer
    2)Makes the RESULT_VALUE float
    3)Removes the time from the datetime EVENT_DATE columns
    4)Make all dates to start from the first day
    5)Adds an extra column with an alternative represenation of the date as Month Year
    6)Takes the mean of measurements taken in the same day
    7)After taking the mean it drops all the duplicate dates
    8)Drop not used columns
    
    """
    #1-2-make ids integers, and result values floats
    biometrics.dropna(subset = ['PERS_ID'], inplace = True)
    biometrics['PERS_ID'] = biometrics['PERS_ID'].astype(int)
    biometrics.RESULT_VALUE = biometrics.RESULT_VALUE.astype(float)

    #2-make dates datetime date
    biometrics.EVENT_DATE = pd.to_datetime(biometrics.EVENT_DATE).dt.date
    
    #3-make all dates to start from the first day
    biometrics.EVENT_DATE = biometrics.EVENT_DATE.apply(make_days1)
    
    #4-add an extra column with an alternative represenation of the date as Month Year
    biometrics['EVENT_DATE_MYR'] = biometrics.EVENT_DATE.apply(make_date_to_MYR)
    
    #5-compute the mean biometric value per month for each patient
    bio_mean = biometrics.groupby(by = ['PERS_ID', 'EVENT_DATE_MYR']).RESULT_VALUE.mean()

    #6-7-drop the duplicate ids-dates tuples and the biometrics results values
    biometrics.drop_duplicates(subset = ['PERS_ID', 'EVENT_DATE_MYR'], inplace = True)
    biometrics.drop(labels = 'RESULT_VALUE', axis = 1, inplace = True)

    #8-merge the mean result values in the initial biometrics dataset
    biometrics = biometrics.merge(bio_mean, on = ['PERS_ID', 'EVENT_DATE_MYR'])

    #drop unecessary columns from biometrics
    biometrics.drop(labels = ['DATE_TYPE', 'CODING_STANDARD', 'SOURCE', 'EVENT_CODE'], inplace = True, axis = 1)
    
    return biometrics

def biometrics_f(biometrics, outcome_under_study = 'BMI', drop_single = True):
    """
    
    1)Processes biometrics data with bio_processing function
    2)filter by the outcome under study 
    3)keep or not subjects that have only a single measurement or not
    
    """
    #filter biometrics data to keep only the outcome of interest
    filt = biometrics.BIOMETRIC_CATEGORY == outcome_under_study
    biometrics = biometrics[filt].reset_index(drop = True)
    
    #process biometrics data with bio processing
    biometrics = bio_processing(biometrics)
    
    #drop ids with single measurements if True
    if drop_single:
        number_of_measurements = biometrics.groupby('PERS_ID').apply(len)
        ids_more_than2 = number_of_measurements[number_of_measurements > 1].index
        biometrics = biometrics[biometrics.PERS_ID.isin(ids_more_than2)]
        
    return biometrics
#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________
#------------------------ BIOMETRICS END-------------------------------


#----------------------- PMPM-----------------------------------
#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________


def pmpm_f(pmpm, enroll_filt = True, enroll_months = 12):
    """
    
    Some processing in PMPM
    1)Make PERSON IDS integers
    2)Transform gender in binary variable
    0---> Female
    1---> Male
    Applies continuous enrollement filtering if enroll_filt is True
    enroll_months: int: number of continuous enrollement months
    
    """
    
    pmpm.PERS_ID = pmpm.PERS_ID.astype(int)
    pmpm.MBR_GNDR = pmpm.MBR_GNDR.replace(['F', 'M'], [0,1])
    pmpm =  pmpm.drop_duplicates(subset = ('PERS_ID', 'MYR')).reset_index(drop = True)
    
    if enroll_filt:
        pmpm = enrollement_filter(pmpm, enroll_months)
    
    
    return pmpm

#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________
#------------------------ PMPM END-------------------------------


#----------------------- Canary-----------------------------------
#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________

def canary_f(canary):
    """
    Canary dataset processing
    1)Drop columns not needed
    2)Change Person Id to int
    3)Make the Register Date and Last Activity Date start from day 1
    4)Add two extra colums with Rergister Date and Last Acivity date to End at
    """
    
    #1-drop extra columns
    canary.drop(labels = ['MBR_ID', 'GROUPNUMBER', 'GROUPNAME', 'LOB', 'FILE_NAME', 'FILE_DATE', 
                      'LAST_COMPLETED_MILESTONE'], axis = 1, inplace = True)
    
    #2-change person id to integer
    canary.PERS_ID = canary.PERS_ID.astype(int)
    
    #3-4
    canary.REGISTER_DATE = canary.REGISTER_DATE.apply(make_days1)
    canary.LAST_ACTIVITY_DATE = canary.LAST_ACTIVITY_DATE.apply(make_days1)
    canary['REGISTER_DATE_MYR'] = canary.REGISTER_DATE.apply(make_date_to_MYR)
    canary['LAST_ACTIVITY_MYR'] = canary.LAST_ACTIVITY_DATE.apply(make_date_to_MYR)
    canary.drop_duplicates(subset = ['PERS_ID'], inplace = True)
    
    return canary.reset_index(drop=True)


#-----------------------Biometrics-PMPM-Canary-----------------------------------
#_____________________________________________________________________
#_____________________________________________________________________
#______________________________________________________________________
def merge_filter_separate(biometrics, pmpm, canary, merge_how = 'inner'):
    """
    1)merge biometrics and pmpm (either with "inner merge" or with "left merge"(for outcome 3))
    2)drop subjects in canary with no values
    in the merged pmpm biometrics file
    3)separates merged pmpm biometrics into treated and controls
    to be processed in a different way for outcomes
    4)merge treated and canary data to a unified dataset
    """
    #1-
    
    #temporary measure ---*
   # merged0 = pmpm.merge(biometrics, how = merge_how, left_on =  ['PERS_ID', 'MYR'], right_on = ['PERS_ID', 'EVENT_DATE_MYR'])
   # merged0.sort_values(by = ['PERS_ID', 'MYR'], inplace = True, ignore_index = True)
    ###############################
    
    merged = pmpm.merge(biometrics, how = merge_how,
                        left_on =  ['PERS_ID', 'MYR'],
                        right_on = ['PERS_ID', 'EVENT_DATE_MYR'])
    merged.sort_values(by = ['PERS_ID', 'MYR'],
                       inplace = True,
                       ignore_index = True)
    
    #2-
    canary = canary[canary.PERS_ID.isin(merged.PERS_ID.unique())].reset_index(drop =True)
    
    #3-
    merged_ids = merged.PERS_ID.unique()
    
    #uncomment for temporary measure ---*
    #merged_ids = merged0.PERS_ID.unique()

    canary_ids = canary.PERS_ID.unique()
    control_ids = np.setdiff1d(merged_ids, canary_ids)
    
    #3-
    filt_cont = merged.PERS_ID.isin(control_ids)
    controls = merged[filt_cont].reset_index(drop = True)
    treated  = merged[~filt_cont].reset_index(drop = True)
    
   #uncomment for temporary measure ---*
   # filt_cont = merged0.PERS_ID.isin(control_ids)
   # filt_cont2 = merged.PERS_ID.isin(canary_ids)
   # controls = merged0[filt_cont].reset_index(drop = True)
   # treated  = merged[filt_cont2].reset_index(drop = True)
    
    #4- merge canary data with treated data
    treated = treated.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    treated2 = pd.merge(treated, canary, on = 'PERS_ID')
    
    return merged, treated2, controls, canary

#------------------OUTCOME CREATIONS-------------------------------------
def control_outcomes(controls, max_days_apart = 180,
                     min_days_apart = 120, threshold = 0,
                     bigger_better = False,
                     window = 3, control_filters = 'old'):
    
    """
    return the controls with their outcomes calculates
    if control_style is old it uses "control_outcomes_old" function
    else it uses control_outcomes_new
    
    """
    
    if control_filters == 'old':
        controls = control_outcomes_old(controls, max_days_apart = max_days_apart,
                                       min_days_apart = min_days_apart, threshold = threshold,
                                       bigger_better = bigger_better,
                                       window = window)
        
    else:
        
        controls = control_outcomes_new(controls, max_days_apart = max_days_apart,
                                       min_days_apart = min_days_apart, threshold = threshold,
                                       bigger_better = bigger_better,
                                       window = window)
        
    return controls

def control_outcomes_new(controls, max_days_apart = 180,
                     min_days_apart = 120, threshold = 0,
                     bigger_better = False,
                     window = 3):
    
    print('Starting Control Outcomes New 0.33s per 100 id processing')
    #sort controls by ID and MYR
    controls = controls.sort_values(by = ['PERS_ID', 'MYR']).reset_index(drop = True)
    
    #fron fill the Result Values according to the window
    controls.RESULT_VALUE = controls.groupby('PERS_ID').RESULT_VALUE.fillna(method = 'ffill', limit = window)
    
    #threshold for outcome3
    if bigger_better:
        controls['RESULT_VALUE2'] = (controls.RESULT_VALUE >= threshold).astype(int)
    else:
        
        controls['RESULT_VALUE2'] = (controls.RESULT_VALUE <= threshold).astype(int)
      
    #put all the nans in outcome 3 as 1
    controls.loc[controls.RESULT_VALUE.isnull(), 'RESULT_VALUE2'] = 1
    
    #make controls EVENT_DATE the same as MYR
    controls.EVENT_DATE = controls.MYR.apply(make_MYR_to_date)
    
    #make outcome columns
    controls['OUTCOME'] = 0
    controls['OUTCOME2'] = 0
    controls['OUTCOME3'] = 0
    
    #make a DAYS columns
    controls['DAYS'] = controls.EVENT_DATE.apply(datetime_to_days)
    idn = len(controls.PERS_ID.unique())
    print("Total of:", idn, "ids, time to finish:", idn/100*0.3,'s')
    
    #find controls with cython and pandas
    controls_final = controls.groupby('PERS_ID').apply(make_control_outcomes_cy, min_days_apart, max_days_apart).reset_index(drop = True)
    
    controls_final.dropna(subset = ['OUTCOME3'], inplace = True)
    controls_final.reset_index(drop = True, inplace = True)
    controls_final.drop(columns = ['DAYS'], inplace = True)
    controls_final.OUTCOME3 = controls.OUTCOME3.replace(to_replace={0:1, 1:1, -1:0})

    controls_final['TREATED'] = 0

    return controls_final


def control_outcomes_old(controls, max_days_apart = 180,
                     min_days_apart = 120, threshold = 0,
                     bigger_better = False,
                     window = 3):
    """
    Creates Outcomes for controls sequencially
    1) Applies time restrictions on how close two measurements
    can be taken apart to be considered a valid outcome
    for example 
    max_days_apart: Maximum number of days between two measurements
    min_days_apart: Minimum number of days between two measuremnts
    control subjects not satisfying this criteria are filtered out
    
    2)Outcome 1: Increase in the biometric value under consideration
    is considered as a 0
    decreased value under consideration is considered as 1
    
    3)Outcome 2: percentage increase in the outcome
    window: how many values of Measurements to be propagated in the future
    
    """
    #calculate the outcomes sequencialy
    controls.sort_values(by = ['PERS_ID', 'MYR'], inplace = True)
    controls.reset_index(drop = True, inplace = True)
    res_value = controls.RESULT_VALUE.values
    
    #outcomes 1 and 2
    outcomes = ((res_value[1:]-res_value[0:-1]) < 0).astype(int)
    outcome2 = ((res_value[1:]-res_value[0:-1])/res_value[0:-1])

    controls = controls.iloc[0:-1]
    controls['OUTCOME'] = outcomes
    controls['OUTCOME2'] = outcome2
    
    #building the 3rd outcome (more losely defined)
    #firts define the reuslt value as a binary vent
    controls['RESULT_VALUE'] = controls.groupby(by = ['PERS_ID']).RESULT_VALUE.fillna(method = 'ffill', 
                                                                                        limit = window)
    if bigger_better:
        controls['RESULT_VALUE2'] = (controls.RESULT_VALUE >= threshold).astype(int)
    else:
        controls['RESULT_VALUE2'] = (controls.RESULT_VALUE <= threshold).astype(int)
        
   

    controls.RESULT_VALUE2[controls.RESULT_VALUE.isnull()] = 1
    res_value2 = controls.RESULT_VALUE2
    outcome3 = res_value2[1:]-res_value2[0:-1]
    
    controls['OUTCOME3'] = outcome3
    controls.OUTCOME3 = controls.OUTCOME3.replace(to_replace={0:1, 1:1, -1:0})

    #drop duplicates that have survived by any chance
    controls = controls.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    
    #drop last date for each person because there is no outcome for that date
    final_dates = controls.groupby('PERS_ID')['MYR'].apply(drop_last).droplevel(1).reset_index()
    controls_final = pd.merge(controls, final_dates, on = ['PERS_ID', 'MYR'], how = 'inner')
    controls_final['TREATED'] = 0
    
    #duplicate MYR to the EVENT DATE
    controls_final['EVENT_DATE'] =  controls_final.MYR.apply(make_MYR_to_date)
    
    #apply time restriction criteria to filter out points which do not satisfy them
    date_diff = pd.Series(controls_final.EVENT_DATE.iloc[1:].values - controls_final.EVENT_DATE.iloc[0: -1].values).dt.days
    time_filt = (date_diff >= min_days_apart) & (date_diff <= max_days_apart)
    controls_final = controls_final.iloc[0:-1][time_filt].reset_index(drop = True)
    
    
    return controls_final

def treated_outcomes(treated, max_days_apart = 180, min_days_apart = 120,
                     threshold = 0, bigger_better = False, window = 3):
    
    """
    construct outcomes for treated patients
    1) Calculate reference values which denote the distance in 
    days from registration and last activity date (they will help us for the filtering)
    REF_START: distance of registration date from the particular date the features were recored
    REF_END: the same as above but for the last activity date
    
    2) picks features based on the function pick_covariates2 
    """
    
    #1-
    treated['EVENT_DATE'] =  treated.MYR.apply(make_MYR_to_date)
    treated['REF_START']  = np.abs(treated.EVENT_DATE - treated.REGISTER_DATE)
    treated['REF_END']    = np.abs(treated.EVENT_DATE - treated.LAST_ACTIVITY_DATE)
    
    treated3 = treated.groupby(by = 'PERS_ID').apply(lambda d: pick_covariates2(d, min_days_apart, 
                                                                                max_days_apart, threshold = threshold,
                                                                               bigger_better = bigger_better,
                                                                                window = window))
    treated3.index = range(len(treated3))
    treated_help = treated3.copy()
    treated3 = treated3[treated3.FF == 0].reset_index(drop = True)
    treated3['TREATED'] = 1
    
    
    return treated3, treated_help

def combine_treated_controls(treated, controls):
    """
    A final combination and merge of controls and treated
    returns: df
    Final dataset for causal analysis
    """
    
    common_columns = np.intersect1d(controls.columns, treated.columns)
    treated_final = treated[common_columns]
    
    df = pd.concat((treated_final, controls), axis = 0, ignore_index = True)
    to_drop = ['EVENT_DATE', 'EVENT_DATE_MYR', 'MYR']
    df = df.drop(labels = to_drop, axis = 1)
    
    return df


#A FINAL HIGH LEVEL FUNCTION TO CREATE THE DATASET

def create_causal_data(canary, pmpm, biometrics, outcome_under_study = 'BMI', drop_single = True,
                      enroll_filt = True, enroll_months = 12, merge_how = "inner",
                      max_days_apart = 180, min_days_apart = 120, 
                       threshold = 0, bigger_better = False, window = 3,
                      control_filters = 'new'):
    """
    
    Used the functions created in the file to create the final causal
    data:
    Functions: 1)biometrics_f
               2)pmpm_f
               3)canary_f
               4)merge_filter_separate
               5)control_outcomes
               6)treated_outcomes
               7)combine_treated_controls
    
    canary: canary data
    pmpm: pmpm data
    biometrics: biometrics data
    outcome_under_study: (str), biometric category to find outcome
    drop_single: Boolean, drop patient is there is a single measurement in biometrics
    enroll_filt: boolean, use enrollment filter or not
    enroll_months:(int),  if enroll_filt is true how many consecutive months
    each patient needs to have
    merge_how:(str), 'inner': common ids and dates between biometrics and pmpm
    'left', ids and dates of pmpm
    max_days_apart: (int), maximum number of days two measurements can be apart to be included for the study
    min_days_apart: (int), minimum number of days two measurements should be apart 
    to be included in the study,
    threshold: When outcome3 is used threshold the result value according to bigger_better flag (see below)
    bigger_better:(boolean)m if this is true a measurement above threshold is considered good (1) else bad (0)
    window; (int) propagate the measuremnts "window" steps in the future: for example if I have a measurement
    at month1 and have no measuremnt at month 4 then window 3 will propagate the measuremnt till month 4
    controls_filters = 'old' (old way ) 'new' new way of filtering controls
    """
    
    biometrics = biometrics_f(biometrics, outcome_under_study, drop_single)
    pmpm = pmpm_f(pmpm, enroll_filt, enroll_months)
    canary = canary_f(canary)
    merged, treated, controls, canary = merge_filter_separate(biometrics, pmpm, canary, merge_how)
    
    controls_final = control_outcomes(controls, max_days_apart, min_days_apart, threshold = threshold, 
                                      bigger_better = bigger_better,
                                     window = window, control_filters = control_filters)
    
    treated_final, treated_help = treated_outcomes(treated, max_days_apart, min_days_apart,
                                                                     threshold = threshold, 
                                                               bigger_better = bigger_better,
                                                                  window = window)
    
    df = combine_treated_controls(treated_final, controls_final)
    
    return df, treated_help



def get_treated_controls(canary, pmpm, biometrics, 
                         outcome_under_study = 'BMI',
                         drop_single = True,
                         enroll_filt = True, 
                         enroll_months = 12,
                         merge_how = "inner"):
    """
    does the intial preprocessing and filtering (continuous enrollement)
    for the data and return the merged data, the controls
    the treated and the canary data back
    from these controls and treated
    we can create the outcomes we want
    
    """
    
    biometrics = biometrics_f(biometrics, outcome_under_study, drop_single)
    pmpm = pmpm_f(pmpm, enroll_filt, enroll_months)
    canary = canary_f(canary)
    merged, treated, controls, canary = merge_filter_separate(biometrics, pmpm, canary, merge_how)
    
    return merged, treated, controls, canary
    




def make_control_outcomes_cy(group, min_days, max_days):
    """
    make control outcomes
    with the new way using cython
    more than 20x faster than the
    make_control_outcomes
    
    """
    
    days = group.DAYS.values
    outcomes = np.zeros(shape = [len(group),3], dtype = float)
    result_values = group[['RESULT_VALUE', 'RESULT_VALUE2']].values
    size = int(len(group))
    
    make_cy(outcomes, result_values, days, int(min_days), int(max_days),  int(size))
   # print(outcomes)
    group[['OUTCOME', 'OUTCOME2', 'OUTCOME3']] = np.array(outcomes)
    
    return group.reset_index(drop = True)

    
    

def make_control_outcomes(group, min_days, max_days):
    """
    group needs to be sorted by MYR
    calculates the control outcomes with
    the new way
    
    """
    #group['OUTCOME'] = 0
    #group['OUTCOME2'] = 0
    #group['OUTCOME3'] = 0
    dates = group.EVENT_DATE
    group = group.reset_index(drop = True)
    
  
   # to_keep = []
    outcomes = []
    result_values = group[['RESULT_VALUE', 'RESULT_VALUE2']].values
    for _,i in enumerate(group.index):
       # print(i)
        datei = group.loc[i, 'EVENT_DATE']
        difference = (dates - datei).dt.days
        filteri = (difference >= min_days) & (difference <= max_days)
        if  filteri.any():
            
           # to_keep.append(i)
            #gg = group[filteri]
            #chosen_val = gg.iloc[0].RESULT_VALUE
            #chosen_val2 = gg.iloc[0].RESULT_VALUE2
           # val = group.loc[i,'RESULT_VALUE']
           # val2 = group.loc[i,'RESULT_VALUE2']
           # group.loc[i, 'OUTCOME1'] = int((chosen_val - val) < 0)
           # group.loc[i, 'OUTCOME2'] = (chosen_val - val)/val
           # group.loc[i, 'OUTCOME3'] = int(chosen_val2-val2)
            
            gg = result_values[filteri]
            chosen_val = gg[0,0]
            chosen_val2 = gg[0,1]

            val = result_values[i,0]
            val2 = result_values[i,1]
            o1 = int((chosen_val - val) < 0)
            o2 = (chosen_val - val)/val
            o3 = int(chosen_val2-val2)
            outcomes.append([o1,o2,o3])
            #outcomes[i,0] = o1
            #outcomes[i,1] = o2
            #outcomes[i,2] = o3
        else:
            #group.loc[i, 'OUTCOME1'] = np.nan
            #group.loc[i, 'OUTCOME2'] = np.nan
            #group.loc[i, 'OUTCOME3'] = np.nan
            outcomes.append([np.nan, np.nan, np.nan])
            #outcomes[i] = np.nan
            
    group[['OUTCOME1', 'OUTCOME2', 'OUTCOME3']] = np.array(outcomes)
    return group.reset_index(drop = True)