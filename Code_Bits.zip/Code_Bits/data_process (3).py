import boto3
from pathlib import Path
import time
import os
import decimal
import pandas as pd
import numpy as np
from path import col_seq_can, col_seq_can_all
import pyarrow.parquet as pq
import time
import datetime as dt
from datetime import datetime
from pathlib import Path
import data_generator
from tqdm import tqdm
from pyspark.sql.types import *
from data_functions import make_date_to_MYR, make_MYR_to_date
from dateutil.relativedelta import relativedelta
from data_functions import  create_causal_data, make_date_to_MYR
from data_functions import  biometrics_f, pmpm_f, canary_f, merge_filter_separate, control_outcomes, treated_outcomes, combine_treated_controls



def download_data(path):

    start_time = time.time()
    s3 = boto3.client('s3')
    Path(path['data_path']).mkdir(exist_ok = 'True')
    Path(path['temp_path']).mkdir(exist_ok = 'True')
    
    try:
        print('Downloading Canary')
        os.system("aws s3 cp " + path['canary_aws_path'] + " " + path['canary_local_path'] + " --recursive;")

        print('Downloading Biometrics')
        os.system("aws s3 cp " + path['biometrics_aws_path'] + " " + path['biometrics_local_path'] + " --recursive;")

        print('Downloading PMPM')
        os.system("aws s3 cp " + path['pmpm_aws_path'] + " " + path['pmpm_local_path'] + " --recursive;")

        s = 'Download Status: Success in Downloading Data'
        
    except:
        s = "Download Status: Failure in Downloading data"

    print(s)
    print("Total Data Download Time:", time.time() - start_time)
    
    
def check_and_download_processed_PMPM(path):
    
    my_file = Path(path['pmpm_processed_local_path'])
    if my_file.is_file():
        pass
    else:
        start_time = time.time()
        s3 = boto3.client('s3')

        try:

            print("Downloading Eligible PMPM")
            success = s3.download_file(path['aws_bucket'], path['pmpm_processed_aws_path'], path['pmpm_processed_local_path'])

            s = 'Download Status: Success in Downloading Data'

        except:
            s = "Download Status: Failure in Downloading data"

        print(s)
        print("Total Data Download Time:", time.time() - start_time)
    
    
def transform_canary(group):
    """
    Function to create an person summary file from
    a canary activity log file
    
    """
    max_mil = group.MILESTONE_NUMBER.max()
    min_mil = group.MILESTONE_NUMBER.min()
    row0 = group[group.MILESTONE_NUMBER == min_mil]
    row1 = group[group.MILESTONE_NUMBER == max_mil]
    
    if len(row0) > 1:
        row0 = pd.DataFrame([row0.iloc[0]], row0.columns)
        
    if len(row1) > 1:
        row1 =  pd.DataFrame([row1.iloc[0]], row1.columns)
        
   
    row1['N_MILESTONES_ACHIEVED'] = max_mil
    row1['LOB'] ='DN'
    row1['LAST_COMPLETED_MILESTONE'] = row1['MILESTONE']
    row1['REGISTER_DATE'] = row0['COMPLETION_DATE'].values[0]
    row1['LAST_ACTIVITY_DATE'] = row1['COMPLETION_DATE'].values[0]
    
    return row1
    
def process_canary(path):
    canary_0 = '../../data/CANARY/CANARY/ACTIVITY_LOG'
    canary_1 = '../../data/CANARY/CANARY/PERSON_SUMMARY'
    canary_2 = '../../data/CANARY/CANARY/CANARY202101'

    canary0 = pq.read_table(canary_0).to_pandas()
    canary1 = pq.read_table(canary_1).to_pandas()
    canary2 = pq.read_table(canary_2).to_pandas()
    
    canary2.dropna(axis = 0, subset = ['MILESTONE'], inplace = True)
    
    milestones = canary2.MILESTONE.unique()
    
    mapper = {"{}TH_LESSON_COMPLETE_DATE".format(i): i for i in range(4,26)}
    mapper['3RD_LESSON_COMPLETE_DATE'] = 3
    mapper['REGISTER_DATE'] = 1
    mapper['ORIENTATION_DATE'] = 2
    mapper['23RD_LESSON_COMPLETE_DATE'] = 23
    mapper['21ST_LESSON_COMPLETE_DATE'] = 21
    mapper['22ND_LESSON_COMPLETE_DATE'] = 22
    
    canary2['MILESTONE_NUMBER'] = canary2.MILESTONE.map(mapper).astype(int)
    
    canary_trans = canary2.groupby('PERS_ID').apply(transform_canary)
    canary_trans = canary_trans.droplevel(0).reset_index(drop = True)
    canary_trans.drop(labels = ['MILESTONE', 'MILESTONE_NUMBER'], inplace = True, axis = 1)
    
    canary_trans.to_pickle(path['canary_processed_local_path'])
    
def process_canary_onset(canary, max_month, path):
    """
    keep only IDs
    transform register date to MYR
    format
    drop data after maximum mont in pmpm
    
    """
    
    canary = canary[['PERS_ID', 'REGISTER_DATE']].copy()
    canary['MYR'] = canary.REGISTER_DATE.apply(make_date_to_MYR)
    canary.drop(columns = ['REGISTER_DATE'], inplace = True)
    canary = canary[canary.MYR <= max_month].reset_index(drop = True)
    
    canary.to_pickle(path['canary_processed_local_path'])
    
def load_data(path):
    
    biometrics_p = path['biometrics_local_path']
    pmpm_p = path['pmpm_processed_local_path']
    biometrics = pq.read_table(biometrics_p).to_pandas()
    pmpm = pd.read_pickle(pmpm_p)
    
    canary = path['canary_local_path'] 
    canary = pq.read_table(canary).to_pandas()
    canary.drop_duplicates(subset = ['PERS_ID'], inplace = True)
    
    return canary, biometrics, pmpm

def gen_diab_onset(pmpm, outcome_col_in_pmpm):

    new_dat = pmpm.loc[:,["PERS_ID","MYR",outcome_col_in_pmpm]]
    new_dat.insert(2, "DATE_TYPE", "CALC_DATE")
    new_dat.insert(3,"BIOMETRIC_CATEGORY",outcome_col_in_pmpm)
    new_dat.insert(4,"EVENT_CODE", "8302-2")
    new_dat.insert(5,"CODING_STANDARD", "LN")
    new_dat.insert(6, "SOURCE", "HIXNY")
    new_dat = new_dat.rename(columns={outcome_col_in_pmpm:"RESULT_VALUE","MYR":"EVENT_DATE"})
    new_dat = new_dat.sort_values(by=["PERS_ID", "EVENT_DATE"])
    new_dat = new_dat[new_dat.PERS_ID>'0']
    new_dat = new_dat.reset_index(drop=True)
    new_dat.EVENT_DATE = new_dat.EVENT_DATE.apply(lambda x: datetime.strftime(datetime.strptime(str(x),"%Y%m"), '%Y-%m-%d %H:%M:%S'))
    
    return new_dat

def transform_features_with_NN(model, df, cols_to_keep, latent_dim=8):
    #project down to latent space
    #--orig latent_features = model.predict(df.loc[:,"MBR_GNDR":])
    
    latent_features = model.predict(df.loc[:,"AGE_AT_MIDMONTH":])
    
    #cols for latent features - converted to df
    latent_col_labels = []
    for i in range(latent_dim):
        latent_col_labels.append("x"+str(i+1))
    latent_features = pd.DataFrame(latent_features, columns=latent_col_labels)
    
    #final transformed df = cols_to_keep from original space + transformed feature
    df_transformed = pd.concat([df[cols_to_keep], latent_features], axis=1)
    
    return df_transformed

def log_(x):
    val = np.log(x + 10**(-7))
    return val
    #return 0 if val <0 else val

def process_PMPM(path, set_name='cc'):
    
    #imports -------------------------------------------------
    import pyspark
    from pyspark import SparkConf
    from pyspark.sql import SparkSession, SQLContext
    import re
    import boto3
    import glob
    import time
    import decimal
    
    # read PMPM using Spark ---------------------------------- 
    # initialise sparkContext
    spark = SparkSession \
        .builder \
        .appName("PMPM PROCESSING") \
        .master("local") \
        .config("spark.dynamicAllocation.enabled", True) \
        .config("spark.executor.cores", 15) \
        .config("spark.dynamicAllocation.minExecutors", 1) \
        .config("spark.dynamicAllocation.maxExecutors", 1) \
        .config('spark.executor.memory', '45g') \
        .config('spark.driver.memory', '45g') \
        .config('spark.sql.execution.arrow.pyspark.enabled', 'true') \
        .config('spark.sql.execution.arrow.pyspark.fallback.enabled', 'true') \
        .getOrCreate()
    
    #path = '../../data/PMPM/'
    #sc = SQLContext(context)
    pmpm = spark.read.parquet(path['pmpm_local_path'])
    
    #get only eligible patients
    pmpm = pmpm.filter(pmpm.IS_CANARY_ELIGIBLE == 1)
    
    #decide which columns to keep/drop
    schema = pmpm.schema.names
    
    #orig-->
    if set_name == "cc":
        match = re.compile(r'^PERS_ID|^CC[\w\s]|^ALLOW_AMT\W*|^ALLOW_IP$|^ALLOW_ER$|MEDICAID_LOB|MYR|AGE_AT_MIDMONTH|MBR_GNDR')
    elif set_name == "elx":
        match = re.compile(r'^PERS_ID|^ELX[\w\s]|ELIXHAUSER|^ALLOW_AMT\W*|^ALLOW_IP$|^ALLOW_ER$|MYR|AGE_AT_MIDMONTH|MBR_GNDR')

    columns_to_keep = []
    columns_to_drop = []
    for sh in schema:
        if match.match(sh) is not None:
            if 'ALLOW_AMT_' not in sh:
                columns_to_keep.append(sh)
        else:
            columns_to_drop.append(sh)
            
    total_cols = np.intersect1d(columns_to_keep, pmpm.columns)
    dr = len(columns_to_drop)
    kp = len(columns_to_keep)
    total = len(schema)
    len(total_cols), dr, kp, dr+kp, total
    
    #filter selected columns using spark
    pmpm_eligible = pmpm.select(list(total_cols))
    
    #write pmpm locally in CSV
    pmpm_eligible.write.csv('temp_pmpm.csv', header = True)
    
    #Read PMPM file from Disk into Pandas
    path = r'temp_pmpm.csv' # use your path
    all_files = glob.glob(path + "/*.csv")

    li = []

    for filename in all_files:
        df = pd.read_csv(filename, index_col=None, header=0)
        li.append(df)

    df = pd.concat(li, axis=0, ignore_index=True)
    
    #Rearrange the columns in pandas array
    cols = list(df.columns)
    col = [cols[-1]] +[cols[-2]] + [cols[-3]] + cols[0:-3]
    df = df[col]
    df.MYR = df.MYR.astype(int)
    df.PERS_ID = df.PERS_ID.astype(str)
    df.AGE_AT_MIDMONTH = df.AGE_AT_MIDMONTH.astype(int)
    df.ALLOW_AMT = df.ALLOW_AMT.astype(int)
    
    #drop duplicates
    df = df.drop_duplicates(subset = ['PERS_ID', 'MYR']).reset_index(drop = True)
    
    return df 

def elx_pmpm_processing(pmpm):
    
    #sort ELX cols 1-31
    elx_cols = sorted(pmpm.columns.to_list()[8:], key = lambda x : int(x.split("ELX_GRP_")[1]))
    
    #new sorted PMPM 
    A = pmpm[pmpm.columns.to_list()[:8]]
    B = pmpm[elx_cols]
    pmpm = pd.concat([A,B], axis=1)
    
    vw_weights = np.array([7, 5, -1, 4, 2, 0, 0, 7, 6, 3, 0, 0, 0, 5, 11, 0, 9, 12, 4, 0, 3, -4, 6, 5, -2, -2, 0, -7, 0, -3])
    
    pmpm["ELX_SCORE"] = np.dot(pmpm.loc[:,"ELX_GRP_1":"ELX_GRP_31"].values, vw_weights)
    
    return pmpm

#----------------------------------------------------------------------------------

def find_records_size(ids, history):
    pers_id       = ids[0] #first column in ids
    current_month = ids[1] #second column in ids
    old_month     = ids[2] #third column in ids
#     current_size  = history.query("PERS_ID==@pers_id & MYR<=@current_month").shape[0]
#     old_size      = history.query("PERS_ID==@pers_id & MYR<=@old_month").shape[0]
    difference    = history.query("PERS_ID==@pers_id & MYR>=@old_month & MYR<=@current_month").shape[0]
    return difference

def get_one_year_before(date, month_offset):
    date_12 = data_functions.make_date_to_MYR(data_functions.make_MYR_to_date(data)+relativedelta(months=-month_offset))
    return date_12

#find worthy candidates
def f1(df, pmpm, required_month = 6, total_month = 12):
    
    #make PERS_ID column to str to compare easily with PMPM backup
    df.PERS_ID = df.PERS_ID.astype(str)
    print("PERS_ID")
    
    #takes the Unique treated IDs and their registration date
    ids_date = df[['PERS_ID','MYR']]
    print("Record Dates")

    #take the date one year before registration date - used george's function from data_function
    ids_date['MYR-12'] = (ids_date.MYR.apply(make_MYR_to_date)+relativedelta(months=-total_month)).apply(make_date_to_MYR)
    print("One year before")
    
    #total history from PMPM for the treated --> Change pmpm name here = global variable
    history = pmpm[pmpm.PERS_ID.isin(ids_date.PERS_ID)].reset_index(drop=True)
    print("History from original pmpm")
    
    #calculate frequency in last 1 year
    tqdm.pandas()
    ids_date['RECORD_SIZE'] = ids_date[['PERS_ID','MYR', 'MYR-12']].progress_apply(find_records_size, axis=1, history=history)
    print("Frequency calculated for last one year")
    
    new_ids_date = ids_date.query("RECORD_SIZE>=@required_month").reset_index(drop=True)
    print("Record filtered")
    print("Returning from f1...")
    
    return new_ids_date

#return the aggregate profile for the worthy candidates
def f2(df, pmpm):
    pers_id    = df[0]
    end_date   = int(df[1])
    start_date = int(df[2])
    pers_history  = pmpm.query("PERS_ID==@pers_id & MYR>=@start_date & MYR<=@end_date")
    agg_history, _   = data_generator.generate_data(pers_history.copy(), start_date, end_date, features=True, col_seq=col_seq_can)
    return agg_history.values[0]
    
def get_average_record(df, pmpm, required_month=6, total_month=12 ):
    df2_ = f1(df, pmpm.copy(), required_month=required_month, total_month=total_month)
    print("f1 done")
    display(df2_.head())
    tqdm.pandas()
    df2 = df2_[['PERS_ID','MYR', 'MYR-12']].progress_apply(f2, axis=1, pmpm=pmpm.copy())
    print("f2 done")
    big_array = df2[0]
    for i in tqdm(range(1,df2.shape[0])):
        big_array = np.vstack((big_array, df2[i]))
    print("stacking done")
    df2 = pd.DataFrame(big_array, columns=col_seq_can)
    df2.insert(1, "MYR", df2_.MYR)
    print("returning..")
    return df2
    
    
def get_average_controls_jeremy(controls, pmpm):
    controls.PERS_ID = controls.PERS_ID.astype(str)
    
    same_control_ids_starting_one_year_old = pmpm[(pmpm.PERS_ID.isin(controls.PERS_ID)) & (pmpm.MYR>=202003)]
    same_control_ids_starting_one_year_old.MBR_GNDR.replace({"F":0,"M":1}, inplace=True)
    same_control_ids_starting_one_year_old["ins"] = 1
    
    frequency_from_202003 = same_control_ids_starting_one_year_old[["PERS_ID", "ins"]].groupby("PERS_ID").aggregate(np.sum).reset_index()
    
    worthy_controls_ids = frequency_from_202003[frequency_from_202003.ins>=10].PERS_ID
    worthy_controls = same_control_ids_starting_one_year_old[same_control_ids_starting_one_year_old.PERS_ID.isin(worthy_controls_ids)]
    
    list_month = [202108, 202107, 202106, 202105, 202104, 202103]
    list_12_month_before = [202008, 202007, 202006, 202005, 202004, 202003]
    
    worthy_controls3 = pd.DataFrame(columns=col_seq_can_all)
    
    for i in range(0,6):
        range_month = (np.arange(12+i, i, -1)*(-1)).tolist()
        print(range_month)
        print(worthy_controls[worthy_controls.MYR==list_month[i]].shape)

        #ids that have records in that particular month
        ids_to_search = worthy_controls[worthy_controls.MYR==list_month[i]].PERS_ID

        aggregated_value = worthy_controls[(worthy_controls.PERS_ID.isin(ids_to_search))& (worthy_controls.MYR>=list_12_month_before[i])].groupby("PERS_ID").aggregate(np.mean).reset_index()

        aggregated_value.MYR = list_month[i]

        worthy_controls3 = pd.concat([worthy_controls3, aggregated_value[col_seq_can_all]], ignore_index=True)

        print(worthy_controls3.shape)
    
    worthy_controls3 = worthy_controls3.sort_values(by=["PERS_ID", 'MYR']).reset_index(drop=True)
    return worthy_controls3

def get_avg_data_OPTIMIZED(df, pmpm, ids_date):
    
    #get worthy samples from original data
    worthy_original = df[df.PERS_ID.isin(ids_date.PERS_ID)]
    
    #get the whole history from PMPM for those worthy samples
    worthy_original_pmpm = pmpm[pmpm.PERS_ID.isin(worthy_original.PERS_ID)]
    
    #select the cols to average and set index as PERS_ID and MYR
    worthy_pmpm_select_cols = worthy_original_pmpm[col_seq_can_all].set_index(['PERS_ID','MYR'])
    
    #get the result, for each sample get the last 12 records average
    worthy_agg = worthy_pmpm_select_cols.join(worthy_pmpm_select_cols.rolling(12).mean().add_prefix('AVG')).filter(regex='^AVG',axis=1)
    
    #only take those sample records from worthy original
    final_agg = worthy_agg[worthy_agg.index.isin(ids_date.set_index(['PERS_ID','MYR']).index)].reset_index().round(decimals=4)
    
    return final_agg