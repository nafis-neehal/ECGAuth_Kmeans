import boto3
from pathlib import Path
import time
import os
import decimal
import pandas as pd
import numpy as np
import pyarrow.parquet as pq
import time
import datetime as dt
from datetime import datetime
from pathlib import Path
from pyspark.sql.types import *
from data_functions import  create_causal_data
from data_functions import  biometrics_f, pmpm_f, canary_f, merge_filter_separate, control_outcomes, treated_outcomes, combine_treated_controls


def download_data(path):

    start_time = time.time()
    s3 = boto3.client('s3')
    Path(path['data_path']).mkdir(exist_ok = 'True')
    Path(path['temp_path']).mkdir(exist_ok = 'True')
    
    try:
        print('Downloading Canary')
        os.system("aws s3 cp " + path['canary_aws_path'] + " " + path['canary_local_path'] + " --recursive;")

        print('Downloading Biometrics')
        os.system("aws s3 cp " + path['biometrics_aws_path'] + " " + path['biometrics_local_path'] + " --recursive;")

        print('Downloading PMPM')
        os.system("aws s3 cp " + path['pmpm_aws_path'] + " " + path['pmpm_local_path'] + " --recursive;")

        print('Downloading Canary December 22 2020')
        os.system("aws s3 cp " + path['canary_new_aws_path'] + " " + path['canary_new_local_path'] + " --recursive;")

        s = 'Download Status: Success in Downloading Data'
        
    except:
        s = "Download Status: Failure in Downloading data"

    print(s)
    print("Total Data Download Time:", time.time() - start_time)
    
    
def check_and_download_processed_PMPM(path):
    
    my_file = Path(path['pmpm_eligible_local_path'])
    if my_file.is_file():
        pass
    else:
        start_time = time.time()
        s3 = boto3.client('s3')

        try:

            print("Downloading Eligible PMPM")
            success = s3.download_file(path['aws_bucket'], path['pmpm_eligible_aws_path'], path['pmpm_eligible_local_path'])

            s = 'Download Status: Success in Downloading Data'

        except:
            s = "Download Status: Failure in Downloading data"

        print(s)
        print("Total Data Download Time:", time.time() - start_time)
    
    
def transform_canary(group):
    """
    Function to create an person summary file from
    a canary activity log file
    
    """
    max_mil = group.MILESTONE_NUMBER.max()
    min_mil = group.MILESTONE_NUMBER.min()
    row0 = group[group.MILESTONE_NUMBER == min_mil]
    row1 = group[group.MILESTONE_NUMBER == max_mil]
    
    if len(row0) > 1:
        row0 = pd.DataFrame([row0.iloc[0]], row0.columns)
        
    if len(row1) > 1:
        row1 =  pd.DataFrame([row1.iloc[0]], row1.columns)
        
   
    row1['N_MILESTONES_ACHIEVED'] = max_mil
    row1['LOB'] ='DN'
    row1['LAST_COMPLETED_MILESTONE'] = row1['MILESTONE']
    row1['REGISTER_DATE'] = row0['COMPLETION_DATE'].values[0]
    row1['LAST_ACTIVITY_DATE'] = row1['COMPLETION_DATE'].values[0]
    
    return row1
    
def process_canary(path):
    canary_0 = '../../data/CANARY/CANARY/ACTIVITY_LOG'
    canary_1 = '../../data/CANARY/CANARY/PERSON_SUMMARY'
    canary_2 = '../../data/CANARY/CANARY/CANARY202101'

    canary0 = pq.read_table(canary_0).to_pandas()
    canary1 = pq.read_table(canary_1).to_pandas()
    canary2 = pq.read_table(canary_2).to_pandas()
    
    canary2.dropna(axis = 0, subset = ['MILESTONE'], inplace = True)
    
    milestones = canary2.MILESTONE.unique()
    
    mapper = {"{}TH_LESSON_COMPLETE_DATE".format(i): i for i in range(4,26)}
    mapper['3RD_LESSON_COMPLETE_DATE'] = 3
    mapper['REGISTER_DATE'] = 1
    mapper['ORIENTATION_DATE'] = 2
    mapper['23RD_LESSON_COMPLETE_DATE'] = 23
    mapper['21ST_LESSON_COMPLETE_DATE'] = 21
    mapper['22ND_LESSON_COMPLETE_DATE'] = 22
    
    canary2['MILESTONE_NUMBER'] = canary2.MILESTONE.map(mapper).astype(int)
    
    canary_trans = canary2.groupby('PERS_ID').apply(transform_canary)
    canary_trans = canary_trans.droplevel(0).reset_index(drop = True)
    canary_trans.drop(labels = ['MILESTONE', 'MILESTONE_NUMBER'], inplace = True, axis = 1)
    
    canary_trans.to_pickle(path['canary_processed_local_path'])
    

def load_data():
    
    canary_p = '../../temp/CANARY.p'
    biometrics_p = '../../data/BIOMETRICS'
    pmpm_p = '../../temp/PMPM.p'

    canary = pd.read_pickle(canary_p)
    biometrics = pq.read_table(biometrics_p).to_pandas()
    pmpm = pd.read_pickle(pmpm_p)
    
    return canary, biometrics, pmpm

def gen_diab_onset(pmpm):

    new_dat = pmpm.loc[:,["PERS_ID","MYR","CC_DIABETES"]]
    new_dat.insert(2, "DATE_TYPE", "CALC_DATE")
    new_dat.insert(3,"BIOMETRIC_CATEGORY","CC_DIABETES")
    new_dat.insert(4,"EVENT_CODE", "8302-2")
    new_dat.insert(5,"CODING_STANDARD", "LN")
    new_dat.insert(6, "SOURCE", "HIXNY")
    new_dat = new_dat.rename(columns={"CC_DIABETES":"RESULT_VALUE","MYR":"EVENT_DATE"})
    new_dat = new_dat.sort_values(by=["PERS_ID", "EVENT_DATE"])
    new_dat = new_dat[new_dat.PERS_ID>'0']
    new_dat = new_dat.reset_index(drop=True)
    new_dat.EVENT_DATE = new_dat.EVENT_DATE.apply(lambda x: datetime.strftime(datetime.strptime(str(x),"%Y%m"), '%Y-%m-%d %H:%M:%S'))
    
    return new_dat

def process_PMPM(path):
    
    #imports -------------------------------------------------
    from pyspark.sql import SparkSession
    from pyspark.sql.functions import col , column
    from pyspark.sql import SQLContext
    import re
    import boto3
    
    
    # read PMPM using Spark ---------------------------------- 
    # initialise sparkContext
    spark = SparkSession.builder \
        .master('local') \
        .appName('myAppName') \
        .config('spark.executor.memory', '20gb') \
        .config("spark.cores.max", "1") \
        .getOrCreate()

    sc = spark.sparkContext
    sqlContext = SQLContext(sc)
    
    print("Spark Session Built..")
    
    #read
    pmpm=sqlContext.read.parquet(path['pmpm_local_path'])
    
    #save column names
    columns = pmpm.columns
    
    #Filter PMPM -------------------------------------------- 
    #filter by eligibility
    pmpm_eligible = pmpm.filter(pmpm.IS_CANARY_ELIGIBLE == 1)
    
    #select columns using Regex
    schema = pmpm_eligible.schema.names
    match = re.compile(r'^PERS_ID|^CC[\w\s]|^ALLOW_AMT[\w\s]*|MYR|AGE_AT_MIDMONTH|MBR_GNDR')
    
    #separate columns to keep/drop
    columns_to_keep = []
    columns_to_drop = []
    for sh in schema:
        if match.match(sh) is not None:
            columns_to_keep.append(sh)
        else:
            columns_to_drop.append(sh)
    
    remove_these_cols = ['PERS_ID', 'ALLOW_AMT_PAID', 'ALLOW_AMT_CAP']
    total_cols = np.setdiff1d(columns_to_keep, remove_these_cols)
    
    #datatype process, delete unnecessary vars
    pmpm_eligible2 = pmpm_eligible.select(columns_to_keep)
    pmpm_eligible2 = pmpm_eligible2.select(
        [col(name) if ('decimal' not in colType) or( name=='MYR') or (name == 'PERS_ID') else col(name).cast(IntegerType()) for name, colType in pmpm_eligible2.dtypes ]
    )
    del pmpm, pmpm_eligible
    
    print("PMPM Columns Selected to load..")
    print("Starting to load columns into program..")
    
    #PMPM Final Column Selection--------------------------------------
    st = time.time()
    df = pmpm_eligible2.select('PERS_ID').toPandas()
    en = time.time() - st
    print("Time for loading PERS_ID column:", en)
    st1 = time.time()
    for i, coll in enumerate(total_cols):
        col_st = time.time()
        df[coll] = pmpm_eligible2.select(coll).toPandas()
        print(f"{i+1}.Column: {coll} loaded, Time Taken: {time.time() - col_st}")
    print(f"Total Time Taken: {time.time() - st1}")
    
    #small post-process
    df.MYR = df.MYR.astype(int)
    
    #save file in temp folder
    df.to_pickle(path['pmpm_eligible_local_path'])
    
    #save in S3 as well
    s3 = boto3.client('s3')
    s3.upload_file(path['pmpm_eligible_local_path'], path['aws_bucket'], path['pmpm_eligible_aws_path'], ExtraArgs = {'ACL':"bucket-owner-full-control", 'ServerSideEncryption':'AES256'})

