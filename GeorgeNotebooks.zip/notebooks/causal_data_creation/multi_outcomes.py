import pandas as pd
import numpy as np
import time
import datetime as dt

from data_functions import create_causal_data



def multi_outcomes_data(pmpm, biometrics, canary, biometrics_list = None, 
                        kwargs_list = None):
    
    """
    takes a list of biometric outcomes(list of strings)
    example: ["BMI", "A1C", ...]
    kwargs_list = list of  dictionaries with parameters for the create_causal_data function
    check there for the possible  parameters
    
    """
    if biometrics_list is None:
        print("Error: please input a valid list with biometrics to consider")
        return
    
    data = []
    print('A total of {} iterations will be run'.format(len(biometrics_list)))
    for i, key in enumerate(biometrics_list):
        start = time.time()
        mapper = {'OUTCOME':'OUTCOME_'+key, 'OUTCOME2':'OUTCOME2_'+key, 'OUTCOME3':'OUTCOME2_'+key, 
                  'BIOMETRIC_CATEGORY':'BIOMETRIC_CATEGORY_'+key}
        if not (kwargs_list is None):
            df, _ = create_causal_data(canary.copy(), pmpm.copy(), biometrics.copy(), 
                      outcome_under_study = key, **kwargs_list[i])
        else:
            df, _ = create_causal_data(canary.copy(), pmpm.copy(), biometrics.copy(), 
                      outcome_under_study = key)
            
        end = time.time() - start
        print("Iteration {} of {}".format(i, len(biometrics_list)))
        print("Created the data for biometrics with name:", key)
        
        data.append(df)
        
        
    return data
        
        
        