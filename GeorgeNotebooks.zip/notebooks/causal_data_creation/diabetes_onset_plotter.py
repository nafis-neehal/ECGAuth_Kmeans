import warnings
def warn(message, category=None, stacklevel=1, source=None):
    pass

warnings.warn = warn
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib as mpl
from sklearn.preprocessing import StandardScaler, MinMaxScaler


from lifelines import CoxPHFitter 
from lifelines import WeibullFitter
from lifelines.statistics import logrank_test
from lifelines.plotting import add_at_risk_counts, rmst_plot
from lifelines.utils import restricted_mean_survival_time
from lifelines import KaplanMeierFitter


from lifelines.plotting import add_at_risk_counts
from pathlib import Path



def plot_onset2(*args, names = None):
    
    fig, ax = plt.subplots(2,2, figsize = (15, 9))
    for i, arg in enumerate(args):
        xx = np.arange(len(arg))
        ax[0,0].plot(xx, arg.Per_1000, label = names[i])
        ax[0,1].plot(xx, arg.Per_1000.cumsum(), label = names[i])
        ax[1,0].plot(xx, arg.Per_1000.cumsum()-arg.Per_1000.cumsum().iloc[33], label = names[i])

    ax[0,0].grid()
    #ax.set_xticks(jointTr.MYR.values)
    #ax.set_xticklabels([str(date) for date in jointTr.MYR.values], rotation = 45)
    ax[0,0].set_xlabel('Months')
    ax[0,0].set_ylabel('Diabetes Onset Per 1000')
    ax[0,0].legend()
    
    ax[0,1].grid()
    ax[0,1].set_xlabel('Months')
    ax[0,1].set_ylabel('Cumulative Diabetes Onset Per 1000')
    ax[0,1].legend()
    
    ax[1,0].set_xlim(left = 33)
    ax[1,0].set_ylim(bottom = 0)
    ax[1,0].set_xlabel('Months')
    ax[1,0].set_ylabel('Cumulative Diabetes Onset Per 1000 after Month 33')
    ax[1,0].legend()
    
    plt.legend()
    return fig, ax

### For paper
def plot_hist(data1, data2, name_mapping, log_norm_names,*, data3 = None,  save_path = 'res/figs/', dist_plot_args = None):
    """
    data1: pandas dataframe 1
    data2: pandas dataframe 2
    name_mapping: pandas columns --> paper columns
    log_norm_names --> names to log normalize
    data3: optional third dataset
    save_path: where to save the barplots
    dist_plot_args: extra arguments for the distribution plots
    
    
    """
    axes = []
    sns.set_context(context = 'paper')
    sns.set_style('white')
    for name, new_name in name_mapping.items():
        fig, ax  = plt.subplots()
        if name in log_norm_names:
            data1[name] = np.log(data1[name]+1)
            data2[name] = np.log(data2[name]+1)
            
            if data3 is not None:
                data3[name] = np.log(data3[name]+1)
     
        try:
            ax = sns.distplot(data2[name], axlabel = new_name,  ax = ax, label = 'Controls', **dist_plot_args, hist_kws = {'color':'r'}, kde_kws = {'color':'r'})
        except RuntimeError as re:
            if str(re).startswith("Selected KDE bandwidth is 0. Cannot estimate density."):
                ax = sns.distplot(data2[name], axlabel = new_name,  ax = ax, label = 'Controls', **dist_plot_args, hist_kws = {'color':'r'}, kde_kws = {'color':'r', 'bw':0.1})
            else:
                raise re
        try:
            ax = sns.distplot(data1[name], axlabel = new_name, ax = ax, label = 'Treated',  **dist_plot_args, hist_kws = {'color':'k'},  kde_kws = {'color':'k'})
        except RuntimeError as re:
            if str(re).startswith("Selected KDE bandwidth is 0. Cannot estimate density."):
                ax = sns.distplot(data1[name], axlabel = new_name, ax = ax, label = 'Treated',  **dist_plot_args, hist_kws = {'color':'k'},  kde_kws = {'color':'k','bw':0.1})
            else:
                raise re
        
        if data3 is not None:
           
            ax = sns.distplot(data3[name],axlabel = new_name,  ax = ax, label = 'General Population',  **dist_plot_args)


        ax.xaxis.label.set_size(12)
        ax.legend(['Controls', 'Treated'],fontsize = 12)
        ax.set_ylabel('Frequency/Density', fontsize = 12 )
        axes.append(ax)
        svname = name.replace(" ", '-')+'.pdf'
        plt.show()
        Path(save_path).mkdir(parents = True, exist_ok = True)
        fig.savefig(save_path+svname, bbox_inches='tight',pad_inches = 0)
    
    return axes


def save_arrays(data, paths, mapping):
    all_paper = data.droplevel(1, axis = 1)
    all_paper.columns = ['Treated', 'Matched Controls', 'T-Statistic', 'p-value', 'General Population', 'Random Match']
    all_paper.index = mapping.values()
    all_paper = all_paper.round(3)
    all_paper.to_csv(paths[0])
    
    only_means = all_paper[['Treated', 'Matched Controls', 'General Population', 'Random Match']]
    only_means.to_csv(paths[1])
    
    all_paper['Difference'] = all_paper['Treated'] - all_paper['Matched Controls']
    only_stats = all_paper[['Difference', 'T-Statistic', 'p-value']]
    only_stats.to_csv(paths[2])
    only_stats
    
    return (all_paper, only_means, only_stats)

def save_arrays2(arrays, names, path):
    Path(path).mkdir(parents = True, exist_ok = True)
    
    for arr, name in zip(arrays, names):
        arr.to_csv(path+name+'.csv')

#### RESULTS ON SURVIVAL

def survival_fit_res(names,  *args, model = None,  model_type = 'Cox',
                     model_args = {}, fit_args = {},
                     duration = 'T', events = 'E',
                    filter_cols = [], normalize = None, log_normalize = None,
                    time = 24, outcome = None):
    """
    *args = all data to plot and get results
    names: names of fitted data
    model: which model to fit: (usually KaplanMeier or CoxPHFitter)
    model_args: dict: model parameters
    fit_args : parameters for fit

    returns: dict(names) --> fitted models
    
    """
    if not model:
        print('ERROR: GIVE MODEL')
        return
    fitted = {}
    
    for dat, name in zip(args, names):
        if filter_cols:
            dat = dat[filter_cols].copy()
            #NORMALIZATION
        if log_normalize is not None:
             dat[log_normalize] = np.log(dat[log_normalize]+1)
        if normalize is not None:
             dat[normalize] = MinMaxScaler().fit_transform(dat[normalize].values)
                
        md = model(**model_args)
        if model_type == 'Cox':
            md = md.fit(dat, duration_col = duration, event_col = events, **fit_args)
        else:
            md = md.fit(dat[duration], event_observed = dat[events], **fit_args)
        
        fitted[name] = md
    models = list(fitted.values())
    diff = []
    for time in [6, 12, 18, 24]:
        rmst1 = restricted_mean_survival_time(models[0], t = time)
        rmst2 = restricted_mean_survival_time(models[1], t = time)
        diff.append(rmst1-rmst2)
        
    
    return fitted,diff
        
def make_results(fitted_models, data1, data2,path_tabs = None,
                 path_figs = None, path_figs2 = None, outcome = None, 
                 model_args = {}, fit_args = {}, surv_model = None,
                 duration = 'T', events = 'E', filter_cols = [], 
                 summary_names = None, log_normalize = None, 
                 normalize = None, kaplan_plot_params = {}, timeline = 24,
                outcome_title = 0, ylim = None, ver_line = False, ver_line_val = 6): 
    """
    fitted_models: dictionary name--> survival models
    data1: first data
    data2: second data
    path_tabs==> path to save tabular data
    path_figs==> path to save regular figures
    outcome ==> name of the outcome studied
    model_args=> dictionary with the parameters of the survival model fitted
    fit_args=> dictionary for the fitting parameters of the survival model
    surv_model==> survival model class trainable 
    duration==> the duration name column
    events == > the event name column
    filter_cols == > list of columns to filter from the data
    summary_names ==> change the names of summary columns for the cox weights and statistics
    log_normalize==> list with columsn to log normalize
    normalize==> list with columns to normalize
    kaplan_plot_params == > dictioonary for the parfameters of thr built in lifelines 
    plot function for kaplan meier curves
    timeline ==> cut the time of study to the prticular timeline
    outcome_title = 0 dont put a title in the graphs, 1 put title and pvalue
    ver_line: put a vertical line  at "ver_line_val"
    ver_line_val:(integer) where to put the vertical line
    """
    #sns.set_context(context = 'paper')
    #sns.set_style('white')
    mpl.style.use('seaborn-paper')
    font = {'family':'Times New Roman',
            'weight': 'normal',
            'size': 16
            }

    axes_font = {'labelsize':20}
    plt.rc('font', **font)
    plt.rc('axes', **axes_font)
    
    #perform the logrank test for the survival data1 and data2
    logrank_summ = logrank_test(data1['T'], data2['T'], event_observed_A=data1['E'], event_observed_B=data2['E'] ).summary
    if outcome is None:
        print('Give the Outcome name:')
       
    logrank_summ.index = [outcome]
    logrank_summ.to_csv(path_tabs+outcome.replace(' ', '_')+'_lgrank.csv')
    
    #make graphs of survival curves according to the fitted models(kaplan or Cox)
    #create plotting area
    fig, ax = plt.subplots()
    for name, model in fitted_models.items():
        
        #plot data on the axes
        if isinstance(model, KaplanMeierFitter):
            ax = model.plot(**kaplan_plot_params, ax = ax)
        else:
            ax = model.baseline_survival_.plot(ax = ax)
    
    try:
        flag = kaplan_plot_params['at_risk_counts']
        if not flag:
            ax = add_at_risk_counts(*list(fitted_models.values()), ax = ax)
    except:
        pass
    
    #customize plots
    ax.collections[0].set_color('r')
    ax.collections[1].set_color('k')
    ax.set_xlabel('Time')#, fontsize =12)
    ax.set_ylabel('Survival')#, fontsize = 12)
    ax.lines[0].set_color('r')
    ax.lines[1].set_color('k')
    ax.legend(list(fitted_models.keys()))#, fontsize = 12)
    if outcome_title:
        ax.set_title(outcome+'\np-value:'+'{:.3f}'.format(logrank_summ['p'].iloc[0]))#, fontsize = 12)
    #save figs
    if ylim:
        ax.set_ylim(bottom = ylim[0])
    if ver_line:
        y_min, y_max = ax.get_ylim()
        ax.vlines(ver_line_val, y_min, y_max, linestyles = 'dashed', colors = ['k'])
    ax.margins(x=0, y=0)
    fig.savefig(path_figs+outcome.replace(' ', '_')+'_survSep.pdf',bbox_inches='tight',pad_inches = 0)
    
    #Use cox regression for matched and controls filter and normalize
    dat = pd.concat((data1, data2), axis = 0, ignore_index = True)
    if log_normalize is not None:
             dat[log_normalize] = np.log(dat[log_normalize]+1)
    if normalize is not None:
             dat[normalize] = MinMaxScaler().fit_transform(dat[normalize].values)
    
    if filter_cols:
        dat = dat[filter_cols].copy()
    
    #fit
    try:
        md = surv_model(**model_args)
        md = md.fit(dat, duration_col = duration, event_col = events, **fit_args)

        ##plot cox models
        fig2, ax2 = plt.subplots()
        ax2 = md.plot_partial_effects_on_outcome(covariates = 'Treatment', values = [0, 1], plot_baseline=False, ax = ax2 )
        ax2.lines[0].set_color('k')
        ax2.lines[1].set_color('r')
        ax2.legend(['Treatment=0', 'Treatment=1', 'baseline'])#, fontsize = 12)
        ax2.set_xlabel('Time')#, fontsize =12)
        ax2.set_xlim(right = timeline)
        ax2.set_ylabel('Survival')#, fontsize = 12)
        if outcome_title:
            ax2.set_title(outcome)#, fontsize = 12)
        if ylim:
            ax2.set_ylim(bottom = ylim[0])
        if ver_line:
            y_min, y_max = ax2.get_ylim()
            ax2.vlines(ver_line_val, y_min, y_max, linestyles = 'dashed',colors = ['k'])
        ax2.margins(x=0, y=0)
        fig2.savefig(path_figs2+outcome.replace(' ', '_')+'_survSep2.pdf',bbox_inches='tight',pad_inches = 0)

        summ = md.summary.round(3)
        if summary_names:
            summ.index = summary_names

        summ = summ[['coef','se(coef)', 'z','p']]
        summ.columns = ['Coefficient', 'Standard Error', 'z-statistic', 'p-value']
        summ.to_csv((path_tabs+outcome.replace(' ', '_')+'_summary.csv'))
    except:
        print('Problem in fitting Cox Model')
        ax2, summ = 0,0
    return logrank_summ, ax, ax2, summ

