from sklearn.neighbors import NearestNeighbors
import numpy as np
import pandas as pd
from sklearn import linear_model
from tqdm import tqdm

class PropensityScoreMatching:
    
    '''
    Takes Covariates as X, treated(0/1) as Y
    Uses LogisticRegression to predict the probabilities of treatment --  propensity score
    Saves in attribute
    '''
    def __init__(self, data):
        
        #variables
        self.matchedControlIndices = None
        self.matchedTreatedIndices = None
        self.ITE = None
        
        #aliases
        X = pd.concat([data.loc[:,:"MBR_GNDR"], data.loc[:,"RESULT_VALUE"]], axis=1)
        T = data.TREATED
        
        #calculate and save propensity score
        propensityScoreModel = linear_model.LogisticRegression(solver='lbfgs')
        propensityScoreModel.fit(X, T)
        self.propensityScoreAll = propensityScoreModel.predict_proba(X)[:,1]
        
        data['PROPENSITY'] = self.propensityScoreAll
        
    '''
    Generates nearest neighbor search space fitted in controls
    For each treated, gets nearest neighbor from control
    save/return those indices of control
    '''
    def getControlsForTreated(self, data):

        #split treated and control
        treated = data.loc[data.TREATED==1]
        control = data.loc[data.TREATED==0]
        
        #nearest neibors will be searched in controls
        control_neighbors = (
            NearestNeighbors(n_neighbors=1, algorithm='ball_tree')
            .fit(control['PROPENSITY'].values.reshape(-1, 1))
        )
        
        #indices = number of treated patients
        _, indices = control_neighbors.kneighbors(treated['PROPENSITY'].values.reshape(-1, 1))
        
        self.matchedControlIndices = indices
    
    '''
    Generates nearest neighbor search space fitted in treated
    For each control, gets nearest neighbor from treated
    save/return those indices of treated
    '''
    def getTreatedForControls(self, data):
        
        #split treated and control
        treated = data.loc[data.TREATED==1]
        control = data.loc[data.TREATED==0]
        
        #nearest neighbour will be searched in treated
        treated_neighbors = (
            NearestNeighbors(n_neighbors=1, algorithm='ball_tree')
            .fit(treated['PROPENSITY'].values.reshape(-1, 1))
        )
        
        #indices = number of control patients
        _, indices = treated_neighbors.kneighbors(control['PROPENSITY'].values.reshape(-1, 1))
        
        self.matchedTreatedIndices = indices
        
    '''
    If treatment is 1, follow steps for ATT for 1 person
    If treatment if 0, follow steps for ATC for 1 person
    Input: takes the covariates for control_data and the treated_data
    Return: return a pandas series of ITE for whole dataset
    '''
    def calculateAndSaveITE(self, data):
        
        ITE = []
        
        #split treated and control
        treated = data.loc[data.TREATED==1]
        control = data.loc[data.TREATED==0]
        
        #shapes
        numTreated = treated.shape[0]
        numControl = control.shape[0]
        
        #nearest neibors
        control_neighbors = (
            NearestNeighbors(n_neighbors=1, algorithm='ball_tree')
            .fit(control['PROPENSITY'].values.reshape(-1, 1))
        )
        
        treated_neighbors = (
            NearestNeighbors(n_neighbors=1, algorithm='ball_tree')
            .fit(treated['PROPENSITY'].values.reshape(-1, 1))
        )
        
        for index, unit in tqdm(data.iterrows()):
                
                #treated group unit
                if unit.TREATED==1:
                    distance, matched_idx = control_neighbors.kneighbors(np.array(unit['PROPENSITY']).reshape(-1, 1))
                    treated_outcome = unit["OUTCOME"].item()
                    control_outcome = control.iloc[np.squeeze(matched_idx)]["OUTCOME"].item()
                    
                #control group unit    
                else:
                    distance, matched_idx = treated_neighbors.kneighbors(np.array(unit['PROPENSITY']).reshape(-1, 1))
                    control_outcome = unit["OUTCOME"].item()
                    treated_outcome = treated.iloc[np.squeeze(matched_idx)]["OUTCOME"].item()
                
                #ITE
                ite = treated_outcome - control_outcome
                ITE.append(ite)
                
        data["ITE"] = np.array(ITE)
        self.ITE = np.array(ITE)
    
    '''
    ATT: Average Treatment Effect for Treated
    Take the mean of ITE for the Treated group
    '''
    def calculateATT(self, data):
        treated = data.loc[data.TREATED==1]
        self.ATT = np.mean(treated.ITE)
        print("ATT is: ",self.ATT)
        
    '''
    ATC: Average Treatment Effect for Control
    Take the mean of ITE for the Control group
    ''' 
    def calculateATC(self, data):
        control = data.loc[data.TREATED==0]
        self.ATC = np.mean(control.ITE)
        print("ATC is: ",self.ATC)
        
    '''
    ATT: Average Treatment Effect for the whole population
    Take the weighted average of ATE and ATC
    '''   
    def calculateATE(self, data):
        #split treated and control
        treated = data.loc[data.TREATED==1]
        control = data.loc[data.TREATED==0]
        
        #shapes
        numTreated = treated.shape[0]
        numControl = control.shape[0]
        
        #calculate ATT and ATC
        ATT = np.mean(treated.ITE)
        ATC = np.mean(control.ITE)
        
        ATE = (ATT*numTreated + ATC*numControl)/(numTreated+numControl)
        self.ATE = ATE
        
        print("ATE is: ",self.ATE)
        